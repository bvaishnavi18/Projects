package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class AdminAddBloodBankFragment extends Fragment {
    private static final String TAG = AdminAddBloodBankFragment.class.getSimpleName();
    EditText etBankName,etBankEmail,etBankPhone,etBankAddress;
    Button btnAddBank;
    Spinner spBankCity;
    String bloodBankID;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    FirebaseAuth fAuth = FirebaseAuth.getInstance();
    List<String> lstCity=new ArrayList<String>();

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_add_blood_bank, null);
        etBankName = root.findViewById(R.id.txtBankName);
        etBankEmail = root.findViewById(R.id.txtBankEmail);
        etBankPhone = root.findViewById(R.id.txtBankPhone);
        etBankAddress=root.findViewById(R.id.txtBankAddress);
        spBankCity = root.findViewById(R.id.spBankCity);
        btnAddBank = root.findViewById(R.id.btnAddBank);
        String[] cityValue= new String[]{"Select Your City", "Kalyan", "Dombivli", "Thakurli", "Ulhasnagar", "Thane","Mulund","Ghatkopar","Kurla","Dadar"};
        for (int i = 0; i < cityValue.length; ++i) {
            lstCity.add(cityValue[i]);
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, lstCity);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBankCity.setAdapter(adapter);

        btnAddBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    BloodBank bloodBank=new BloodBank();
                    bloodBank.setBloodBankName(String.valueOf(etBankName.getText().toString()));
                    bloodBank.setBloodBankEmail(String.valueOf(etBankEmail.getText().toString()));
                    bloodBank.setBloodBankPhone(String.valueOf(etBankPhone.getText().toString()));
                    bloodBank.setBloodBankCity(String.valueOf(spBankCity.getSelectedItem().toString()));
                    bloodBank.setBloodBankAddress(String.valueOf(etBankName.getText().toString()));
                    fStore.collection("BloodBank").add(bloodBank).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentReference> task) {
                            if(task.isSuccessful())
                            {
                                bloodBankID=String.valueOf(task.getResult().getId());
                                String[] bloodvalues = new String[] {"A+" , "A-" , "B+" , "B-" , "AB+" , "AB-" ,"O+" , "O-" };
                                for(int i=0;i<bloodvalues.length;i++)
                                {
                                    BloodStock bloodStock=new BloodStock();
                                    bloodStock.setBloodBankID(String.valueOf(bloodBankID));
                                    bloodStock.setBloodQuantity(Integer.valueOf(0));
                                    bloodStock.setBloodGroup(String.valueOf(bloodvalues[i]));
                                    fStore.collection("BloodStock").add(bloodStock).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentReference> task2) {
                                            if(task2.isSuccessful())
                                            {
                                                AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                                                AdminDisplayBloodBankFragment newFragment = new AdminDisplayBloodBankFragment();
                                                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,newFragment).addToBackStack("addbloodbank").commit();
                                            }
                                        }
                                    });
                                }
                                Toasty.success(getContext(), "Added Blood Bank Successfully!!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG,e.getMessage());
                            Toasty.error(getContext(), "Failed to Add Blood Bank!!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toasty.error(getContext(), "Invalid Data!!", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return root;
    }

    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }

        return (Activity) context;
    }
    public boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etBankName.getText().toString().equals("")||etBankEmail.getText().toString().equals("")||etBankPhone.getText().toString().equals("")||etBankAddress.getText().toString().equals(""))
        {
            isDataValid=false;
        }
        if(spBankCity.getSelectedItem().toString().equals("Select Your City"))
        {
            isDataValid=false;
            Toasty.error(getContext(), "Please Select City", Toast.LENGTH_SHORT).show();
        }
        if(!(etBankPhone.getText().toString().matches("[0-9]{10}"))) {
            isDataValid = false;
            etBankPhone.setError("Invalid Phone Number");
            etBankPhone.requestFocus();
        }
        if(!(etBankEmail.getText().toString().matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"))){
            isDataValid=false;
            etBankEmail.setError("Invalid Email ID");
            etBankEmail.requestFocus();
        }
        return isDataValid;
    }
}
