package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class AdminAddBloodDriveFragment extends Fragment {
    private static final String TAG=AdminAddBloodDriveFragment.class.getSimpleName();
    EditText etDriveName,etDriveContactNo,etDriveVenue;
    Spinner spBloodCity,spBloodBank;
    TextView tvDriveDate,tvDriveStartTime,tvDriveEndTime,tvConductedBy;
    Button btnAddDrive;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    private List<String> lstCity,lstBloodBankID,lstBloodBankName;
    private DatePickerDialog.OnDateSetListener sDateSetListener;
    TimePickerDialog timePickerDialog,timePickerDialog2;
    Calendar calendar;
    int currentHour,currentMinute,currentHour2,currentMinute2;
    int year,month,day;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_add_blood_drive, null);
        etDriveName=root.findViewById(R.id.txtDriveName);
        etDriveContactNo=root.findViewById(R.id.txtDriveContact);
        etDriveVenue=root.findViewById(R.id.txtDriveVenue);
        spBloodCity=root.findViewById(R.id.spBloodCity);
        spBloodBank=root.findViewById(R.id.spBloodBank);
        tvDriveDate=root.findViewById(R.id.etBloodDriveDate);
        tvDriveStartTime=root.findViewById(R.id.etBloodDriveStartTime);
        tvDriveEndTime=root.findViewById(R.id.etBloodDriveEndTime);
        tvConductedBy=root.findViewById(R.id.textView6);
        btnAddDrive=root.findViewById(R.id.btnAddBloodDrive2);
        lstCity=new ArrayList<String>();

        tvDriveDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                year = cal.get(Calendar.YEAR);
                month = cal.get(Calendar.MONTH);
                day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(getContext(),sDateSetListener,year,month,day);
                dialog.show();
            }
        });
        sDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                tvDriveDate.setText(String.format("%02d/%02d/%02d",day,month,year));
            }
        };

        tvDriveStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar=Calendar.getInstance();
                currentHour=calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute=calendar.get(Calendar.MINUTE);
                timePickerDialog= new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        tvDriveStartTime.setText(String.format("%02d:%02d",hourOfDay,minute));
                    }
                },currentHour,currentMinute,false);
                timePickerDialog.show();
            }
        });
        tvDriveEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar=Calendar.getInstance();
                currentHour2=calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute2=calendar.get(Calendar.MINUTE);
                timePickerDialog2= new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        tvDriveEndTime.setText(String.format("%02d:%02d",hourOfDay,minute));
                    }
                },currentHour2,currentMinute2,false);
                timePickerDialog2.show();
            }
        });

        //Loading City Spinner
        String[] cityValues= new String[]{"Select Your City", "Kalyan", "Dombivli", "Thakurli", "Ulhasnagar", "Thane","Mulund","Ghatkopar","Kurla","Dadar"};
        for (int i = 0; i < cityValues.length; ++i) {
            lstCity.add(cityValues[i]);
        }
        final ArrayAdapter<String> adapter=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstCity);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBloodCity.setAdapter(adapter);

        //Loading Blood Bank List Spinner
        lstBloodBankID=new ArrayList<String>();
        lstBloodBankName=new ArrayList<String>();
        lstBloodBankID.add("Random ID");
        lstBloodBankName.add("Select Blood Bank");
        fStore.collection("BloodBank").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for(QueryDocumentSnapshot docSnapshot:task.getResult())
                {
                    lstBloodBankID.add(docSnapshot.getId());
                    lstBloodBankName.add(docSnapshot.getString("bloodBankName"));
                }
            }
        });
        final ArrayAdapter<String> adapter2=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstBloodBankName);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBloodBank.setAdapter(adapter2);

        btnAddDrive.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    LocalDate driveDate=LocalDate.parse(tvDriveDate.getText().toString(),dateFormat);

                    LocalTime driveStartTime = LocalTime.parse(tvDriveStartTime.getText().toString());
                    LocalDateTime startDateTime = LocalDateTime.of(driveDate, driveStartTime);
                    String strDateTime = startDateTime.format(dateTimeFormatter);
                    Timestamp startStamp = Timestamp.valueOf(strDateTime);
                    final Long startStampVal = startStamp.getTime();

                    LocalTime driveEndTime = LocalTime.parse(tvDriveEndTime.getText().toString());
                    LocalDateTime endDateTime = LocalDateTime.of(driveDate, driveEndTime);
                    String strDateTime2 = endDateTime.format(dateTimeFormatter);
                    Timestamp endStamp = Timestamp.valueOf(strDateTime2);
                    final Long endStampVal = endStamp.getTime();

                    LocalDateTime localDateTime = LocalDateTime.now();
                    String strCurTime = localDateTime.format(dateTimeFormatter);
                    Timestamp curTimeStamp = Timestamp.valueOf(strCurTime);
                    final Long curStampVal = curTimeStamp.getTime();

                    if((startStampVal < endStampVal) && (curStampVal <= startStampVal))
                    {
                        BloodDrive bloodDrive=new BloodDrive();
                        Integer spinitemid = spBloodBank.getSelectedItemPosition();
                        String bloodBankID = lstBloodBankID.get(spinitemid);
                        bloodDrive.setDriveName(String.valueOf(etDriveName.getText().toString()));
                        bloodDrive.setDriveContactNo(String.valueOf(etDriveContactNo.getText().toString()));
                        bloodDrive.setDriveVenue(String.valueOf(etDriveVenue.getText().toString()));
                        bloodDrive.setBloodBankID(String.valueOf(bloodBankID));
                        bloodDrive.setDriveCity(String.valueOf(spBloodCity.getSelectedItem().toString()));
                        bloodDrive.setDriveDate(String.valueOf(tvDriveDate.getText().toString()));
                        bloodDrive.setDriveStartTime(String.valueOf(tvDriveStartTime.getText().toString()));
                        bloodDrive.setDriveEndTime(String.valueOf(tvDriveEndTime.getText().toString()));
                        bloodDrive.setDriveStartTimeStamp(Long.valueOf(startStampVal));
                        bloodDrive.setDriveEndTimeStamp(Long.valueOf(endStampVal));
                        fStore.collection("BloodDrive").add(bloodDrive).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                Toasty.success(getContext(), "Blood Drive Added Successfully!!", Toast.LENGTH_SHORT).show();
                                AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                                AdminDisplayBloodDriveFragment newFragment = new AdminDisplayBloodDriveFragment();
                                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,newFragment).addToBackStack("addblooddrive").commit();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e(TAG,e.getMessage());
                                Toasty.error(getContext(), "Failed to Add Blood Drive!!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else
                    {
                        Toasty.error(getContext(), "Invalid Date or Time", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return root;
    }
    public Boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etDriveName.getText().toString().equals("")||etDriveContactNo.getText().toString().equals("")||etDriveVenue.getText().toString().equals("")||spBloodCity.getSelectedItem().toString().equals("Select Your City")||spBloodBank.getSelectedItem().toString().equals("Select Blood Bank")||tvDriveDate.getText().toString().equals("__________________")||tvDriveStartTime.getText().toString().equals("__________________")||tvDriveEndTime.getText().toString().equals("__________________"))
        {
            isDataValid=false;
        }
        if(!(etDriveContactNo.getText().toString().matches("[0-9]{10}"))){
            isDataValid=false;
            etDriveContactNo.setError("Invalid Phone Number");
            etDriveContactNo.requestFocus();
        }
        return isDataValid;
    }

    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }
        return (Activity) context;
    }
}