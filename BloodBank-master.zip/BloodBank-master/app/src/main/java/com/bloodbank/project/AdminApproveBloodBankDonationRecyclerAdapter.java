package com.bloodbank.project;

import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import es.dmoral.toasty.Toasty;

public class AdminApproveBloodBankDonationRecyclerAdapter extends FirestoreRecyclerAdapter<BloodDonation, AdminApproveBloodBankDonationRecyclerAdapter.AdminApproveBloodBankDonationViewHolder> {
    private static final String TAG=AdminApproveBloodBankDonationRecyclerAdapter.class.getSimpleName();
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    Context context;

    public AdminApproveBloodBankDonationRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodDonation> options, Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminApproveBloodBankDonationViewHolder holder, int position, @NonNull BloodDonation bloodDonation) {
        String userID=String.valueOf(bloodDonation.getUserID());
        fStore.collection("User").document(String.valueOf(bloodDonation.getUserID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                if(task1.isSuccessful())
                {
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                    LocalDateTime localDateTime = LocalDateTime.now();
                    String strCurTime = localDateTime.format(dateTimeFormatter);
                    String strCurDate=localDateTime.format(dateFormat);
                    Timestamp curTimeStamp = Timestamp.valueOf(strCurTime);
                    final Long curStampVal = curTimeStamp.getTime();

                    DocumentSnapshot docSnapshot1=task1.getResult();
                    holder.tvDonorName.setText("Name: "+String.valueOf(docSnapshot1.getString("userName")));
                    holder.tvDonorBloodGroup.setText("Blood Group: "+String.valueOf(docSnapshot1.getString("bloodGroup")));
                    holder.tvDonationDate.setText("Date: "+String.valueOf(bloodDonation.getDonationDate()));
                    fStore.collection("BloodBank").document(String.valueOf(bloodDonation.getBloodBankID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task2) {
                            if(task2.isSuccessful())
                            {
                                DocumentSnapshot docSnapshot2=task2.getResult();
                                holder.tvBloodDrive.setVisibility(View.GONE);
                                holder.tvBloodBank.setText("Blood Bank: "+String.valueOf(docSnapshot2.getString("bloodBankName")));
                                holder.tvDonationAddress.setText("Address: "+String.valueOf(docSnapshot2.getString("bloodBankAddress")));
                            }
                        }
                    });
                    holder.btnApproveDonation.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            fStore.collection("BloodStock").whereEqualTo("bloodBankID",String.valueOf(getSnapshots().getSnapshot(position).getString("bloodBankID"))).whereEqualTo("bloodGroup",String.valueOf(getSnapshots().getSnapshot(position).getString("bloodGroup"))).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task4) {
                                    if(task4.isSuccessful())
                                    {
                                        DocumentSnapshot docSnapshot4=task4.getResult().getDocuments().get(0);
                                        Log.i(TAG,"BloodStockID: "+String.valueOf(docSnapshot4.getId()));
                                        Integer curStock=Integer.valueOf(docSnapshot4.get("bloodQuantity",Integer.TYPE));
                                        Log.i(TAG,"Current Stock of "+String.valueOf(bloodDonation.getBloodGroup())+": "+String.valueOf(curStock));
                                        Integer newStock=Integer.valueOf(Integer.valueOf(curStock)+Integer.valueOf(1));
                                        Log.i(TAG,"New Stock of "+String.valueOf(bloodDonation.getBloodGroup())+": "+String.valueOf(newStock));
                                        fStore.collection("BloodStock").document(String.valueOf(docSnapshot4.getId())).update("bloodQuantity",Integer.valueOf(newStock)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task5) {
                                                fStore.collection("BloodDonation").document(getSnapshots().getSnapshot(position).getId()).update("donationStatus","Approved","donationTimeStamp",Long.valueOf(curStampVal),"donationDate",String.valueOf(strCurDate)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        MailSender sender=new MailSender();
                                                        sender.sendMail("BloodBank Donation Approval","This is to inform you that your DONATION has been approved successfully",userID);
                                                        Log.i(TAG,"Donation Request Approved Successfully!!");
                                                        Toasty.success(context,"Donation Request Approved Sucessfully!!", Toast.LENGTH_SHORT).show();
                                                        notifyDataSetChanged();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    });

                    holder.btnDenyDonation.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            fStore.collection("BloodDonation").document(getSnapshots().getSnapshot(position).getId()).update("donationStatus","Denied","donationTimeStamp",Long.valueOf(curStampVal),"donationDate",String.valueOf(strCurDate)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Log.i(TAG,"Donation Request Denied Successfully!!");
                                    Toasty.error(context,"Donation Request Denied Sucessfully!!", Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();
                                }
                            });
                        }
                    });

                    StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                }
            }
        });
    }

    @NonNull
    @Override
    public AdminApproveBloodBankDonationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_approve_donation,parent,false);
        return new AdminApproveBloodBankDonationRecyclerAdapter.AdminApproveBloodBankDonationViewHolder(view);
    }

    public static class AdminApproveBloodBankDonationViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvDonorName,tvDonorBloodGroup,tvDonationDate,tvBloodDrive,tvBloodBank,tvDonationAddress;
        Button btnApproveDonation,btnDenyDonation;
        CardView ApproveDonationLinLayout;
        public AdminApproveBloodBankDonationViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvDonorName =(TextView)itemView.findViewById(R.id.tv_donor_name2);
            tvDonorBloodGroup =(TextView)itemView.findViewById(R.id.tv_donor_blood_group2);
            tvDonationDate =(TextView)itemView.findViewById(R.id.tv_donation_date);
            tvBloodDrive =(TextView)itemView.findViewById(R.id.tv_donation_blood_drive);
            tvBloodBank =(TextView)itemView.findViewById(R.id.tv_donation_blood_bank);
            tvDonationAddress =(TextView)itemView.findViewById(R.id.tv_donation_address);
            btnApproveDonation=(Button)itemView.findViewById(R.id.btnApproveDonation);
            btnDenyDonation=(Button)itemView.findViewById(R.id.btnDenyDonation);
            ApproveDonationLinLayout =(CardView)itemView.findViewById(R.id.cardViewApproveDonation);
        }
    }
}
