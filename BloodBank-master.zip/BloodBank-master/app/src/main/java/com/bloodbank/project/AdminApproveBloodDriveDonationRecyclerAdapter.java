package com.bloodbank.project;

import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import es.dmoral.toasty.Toasty;

public class AdminApproveBloodDriveDonationRecyclerAdapter extends FirestoreRecyclerAdapter<BloodDonation,AdminApproveBloodDriveDonationRecyclerAdapter.AdminApproveBloodDriveDonationViewHolder> {
    private static final String TAG=AdminApproveBloodDriveDonationRecyclerAdapter.class.getSimpleName();
    Context context;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    public AdminApproveBloodDriveDonationRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodDonation> options,Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminApproveBloodDriveDonationViewHolder holder, int position, @NonNull BloodDonation bloodDonation) {
        String userID=String.valueOf(bloodDonation.getUserID());
        fStore.collection("User").document(userID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                if(task1.isSuccessful())
                {
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    LocalDateTime localDateTime = LocalDateTime.now();
                    String strCurTime = localDateTime.format(dateTimeFormatter);
                    Timestamp curTimeStamp = Timestamp.valueOf(strCurTime);
                    final Long curStampVal = curTimeStamp.getTime();

                    DocumentSnapshot docSnapshot1=task1.getResult();
                    holder.tvDonorName.setText("Name: "+String.valueOf(docSnapshot1.getString("userName")));
                    holder.tvDonorBloodGroup.setText("Blood Group: "+String.valueOf(docSnapshot1.getString("bloodGroup")));
                    holder.tvDonationDate.setText("Date: "+String.valueOf(bloodDonation.getDonationDate()));
                    fStore.collection("BloodDrive").document(String.valueOf(bloodDonation.getBloodDriveID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task2) {
                            DocumentSnapshot docSnapshot2=task2.getResult();
                            holder.tvBloodDrive.setText("Drive Name: "+String.valueOf(docSnapshot2.getString("driveName")));
                            holder.tvDonationAddress.setText("Venue: "+String.valueOf(docSnapshot2.getString("driveVenue")));
                            fStore.collection("BloodBank").document(String.valueOf(bloodDonation.getBloodBankID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task3) {
                                    if(task3.isSuccessful())
                                    {
                                        DocumentSnapshot docSnapshot3=task3.getResult();
                                        holder.tvBloodBank.setText("Blood Bank: "+String.valueOf(docSnapshot3.getString("bloodBankName")));
                                    }
                                }
                            });
                        }
                    });

                    holder.btnApproveDonation.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            fStore.collection("BloodStock").whereEqualTo("bloodBankID",String.valueOf(bloodDonation.getBloodBankID())).whereEqualTo("bloodGroup",String.valueOf(bloodDonation.getBloodGroup())).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task4) {
                                    if(task4.isSuccessful())
                                    {
                                        DocumentSnapshot docSnapshot4=task4.getResult().getDocuments().get(0);
                                        Integer curStock=Integer.valueOf(docSnapshot4.get("bloodQuantity",Integer.TYPE));
                                        Log.i(TAG,"Current Stock of "+String.valueOf(bloodDonation.getBloodGroup())+": "+String.valueOf(curStock));
                                        Integer newStock=Integer.valueOf(Integer.valueOf(curStock)+Integer.valueOf(1));
                                        Log.i(TAG,"New Stock of "+String.valueOf(bloodDonation.getBloodGroup())+": "+String.valueOf(newStock));
                                        fStore.collection("BloodStock").document(docSnapshot4.getId()).update("bloodQuantity",Integer.valueOf(newStock)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task5) {
                                                fStore.collection("BloodDonation").document(getSnapshots().getSnapshot(position).getId()).update("donationStatus","Approved","donationTimeStamp",Long.valueOf(curStampVal)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task6) {
                                                        if(task6.isSuccessful())
                                                        {
                                                            MailSender sender=new MailSender();
                                                            sender.sendMail("BloodDrive Donation Approval","This is to inform you that your DONATION has been approved successfully",userID);
                                                            Log.i(TAG,"Donation Request Approved Successfully!!");
                                                            Toasty.success(context,"Donation Request Approved Sucessfully!!", Toast.LENGTH_SHORT).show();
                                                            notifyDataSetChanged();
                                                        }
                                                    }
                                                });
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    });
                    holder.btnDenyDonation.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            fStore.collection("BloodDonation").document(getSnapshots().getSnapshot(position).getId()).update("donationStatus","Denied","donationTimeStamp",Long.valueOf(curStampVal)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Log.i(TAG,"Donation Request Denied Successfully!!");
                                    Toasty.error(context,"Donation Request Denied Sucessfully!!", Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();
                                }
                            });
                        }
                    });
                    StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                }
            }
        });
    }

    @NonNull
    @Override
    public AdminApproveBloodDriveDonationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_approve_donation,parent,false);
        return new AdminApproveBloodDriveDonationRecyclerAdapter.AdminApproveBloodDriveDonationViewHolder(view);
    }

    public static class AdminApproveBloodDriveDonationViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvDonorName,tvDonorBloodGroup,tvDonationDate,tvBloodDrive,tvBloodBank,tvDonationAddress;
        Button btnApproveDonation,btnDenyDonation;
        CardView ApproveDonationLinLayout;
        public AdminApproveBloodDriveDonationViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvDonorName =(TextView)itemView.findViewById(R.id.tv_donor_name2);
            tvDonorBloodGroup =(TextView)itemView.findViewById(R.id.tv_donor_blood_group2);
            tvDonationDate =(TextView)itemView.findViewById(R.id.tv_donation_date);
            tvBloodDrive =(TextView)itemView.findViewById(R.id.tv_donation_blood_drive);
            tvBloodBank =(TextView)itemView.findViewById(R.id.tv_donation_blood_bank);
            tvDonationAddress =(TextView)itemView.findViewById(R.id.tv_donation_address);
            btnApproveDonation=(Button)itemView.findViewById(R.id.btnApproveDonation);
            btnDenyDonation=(Button)itemView.findViewById(R.id.btnDenyDonation);
            ApproveDonationLinLayout =(CardView)itemView.findViewById(R.id.cardViewApproveDonation);
        }
    }
}
