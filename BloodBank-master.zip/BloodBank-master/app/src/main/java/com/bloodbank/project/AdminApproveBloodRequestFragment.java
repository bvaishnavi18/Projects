package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminApproveBloodRequestFragment extends Fragment {
    private RecyclerView approveBloodRequestRecyclerView;
    private AdminApproveBloodRequestRecyclerAdapter adapter;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    int count=0;
    Query query;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_approve_blood_request, null);
        approveBloodRequestRecyclerView=(RecyclerView) root.findViewById(R.id.Approve_Blood_Request_RecyclerView);
        fStore.collection("BloodRequest").whereEqualTo("status","Pending").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful())
                {
                    for (QueryDocumentSnapshot documentSnapshot:task.getResult()) {
                        count++;
                    }
                    if (count!=0)
                    {
                        query=fStore.collection("BloodRequest").whereEqualTo("status","Pending");
                        FirestoreRecyclerOptions<BloodRequest> reqOpt=new FirestoreRecyclerOptions.Builder<BloodRequest>().setQuery(query,BloodRequest.class).build();
                        adapter=new AdminApproveBloodRequestRecyclerAdapter(reqOpt,getContext());
                        approveBloodRequestRecyclerView.setAdapter(adapter);
                        approveBloodRequestRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();

                    }
                    else {

                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyRecyclerAdapter=new EmptyRecyclerAdapter<>(getContext(),"No Blood Request Found");
                        approveBloodRequestRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        approveBloodRequestRecyclerView.setAdapter(emptyRecyclerAdapter);
                    }
                }
            }
        });
        return root;
    }
}