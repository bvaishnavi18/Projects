package com.bloodbank.project;

import android.app.Dialog;
import android.content.Context;
import android.os.StrictMode;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class AdminApproveBloodRequestRecyclerAdapter extends FirestoreRecyclerAdapter<BloodRequest,AdminApproveBloodRequestRecyclerAdapter.AdminApproveRequestViewHolder> {
    Context context;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    private static final String TAG = AdminApproveDonorRecyclerAdapter.class.getSimpleName();
    private Dialog dialog;
    private List<String> lstBloodBank,lstBloodBankID,lstDisplay;
    private Spinner spBloodBank;
    private Button btnSelect;
    int count;
    public AdminApproveBloodRequestRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodRequest> options,Context context) {
        super(options);
        this.context=context;
    }
    @NonNull
    @Override
    public AdminApproveRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_admin_approve_blood_request,parent,false);
        return new AdminApproveBloodRequestRecyclerAdapter.AdminApproveRequestViewHolder(view);
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminApproveRequestViewHolder holder, int position, @NonNull BloodRequest bloodRequest) {
        String userID=String.valueOf(bloodRequest.getUserID());
        holder.tvRecipientName.setText("Name: "+bloodRequest.getRecipientName());
        holder.tvRecipientPhone.setText("Phone Number: "+bloodRequest.getRecipientPhone());
        holder.tvRecipientCity.setText("City: "+bloodRequest.getRecipientCity());
        holder.tvRecipientBloodGroup.setText("Blood Group: "+bloodRequest.getRecipientBloodGroup());
        holder.btnAcceptRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog=new Dialog(context);
                dialog.setContentView(R.layout.dialogbox_select_bloodbank);
                lstBloodBank=new ArrayList<>();
                lstBloodBankID=new ArrayList<>();
                lstDisplay=new ArrayList<>();
                spBloodBank=dialog.findViewById(R.id.spBloodBank1);
                btnSelect=dialog.findViewById(R.id.btnSelectBank);
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width=WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height=WindowManager.LayoutParams.WRAP_CONTENT;
                layoutParams.gravity= Gravity.CENTER;
                dialog.getWindow().setAttributes(layoutParams);
                lstBloodBank.add("Select Blood Bank");
                lstBloodBankID.add("Random ID");
                lstDisplay.add("Select Blood Bank");
                fStore.collection("BloodBank").whereEqualTo("bloodBankCity",String.valueOf(bloodRequest.getRecipientCity())).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task1) {
                        if(task1.isSuccessful())
                        {
                            for(QueryDocumentSnapshot queryDocumentSnapshot:task1.getResult())
                            {
                                fStore.collection("BloodStock").whereEqualTo("bloodBankID",String.valueOf(queryDocumentSnapshot.getId())).whereEqualTo("bloodGroup",String.valueOf(bloodRequest.getRecipientBloodGroup())).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task2) {
                                        if(task2.isSuccessful())
                                        {
                                            DocumentSnapshot docSnapshot=task2.getResult().getDocuments().get(0);
                                            lstBloodBankID.add(queryDocumentSnapshot.getId());
                                            lstBloodBank.add(queryDocumentSnapshot.getString("bloodBankName"));
                                            lstDisplay.add(queryDocumentSnapshot.getString("bloodBankName")+" - "+String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE).toString()));
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
                final ArrayAdapter<String> catAdapter=new ArrayAdapter<String>(context,android.R.layout.simple_spinner_item,lstDisplay);
                catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spBloodBank.setAdapter(catAdapter);
                dialog.show();

                btnSelect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        fStore.collection("BloodStock").whereEqualTo("bloodBankID",String.valueOf(lstBloodBankID.get(spBloodBank.getSelectedItemPosition()))).whereEqualTo("bloodGroup",String.valueOf(bloodRequest.getRecipientBloodGroup())).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task3) {
                                if(task3.isSuccessful())
                                {
                                    DocumentSnapshot docSnapshot3=task3.getResult().getDocuments().get(0);
                                    Integer curStock=Integer.valueOf(docSnapshot3.get("bloodQuantity",Integer.TYPE));
                                    Log.i(TAG,"Current Stock of "+String.valueOf(bloodRequest.getRecipientBloodGroup())+": "+String.valueOf(curStock));
                                    Integer newStock=Integer.valueOf(Integer.valueOf(curStock)-Integer.valueOf(1));
                                    Log.i(TAG,"New Stock of "+String.valueOf(bloodRequest.getRecipientBloodGroup())+": "+String.valueOf(newStock));
                                    fStore.collection("BloodStock").document(String.valueOf(docSnapshot3.getId())).update("bloodQuantity",Integer.valueOf(newStock)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task4) {
                                            if(task4.isSuccessful())
                                            {
                                                fStore.collection("BloodRequest").document(getSnapshots().getSnapshot(position).getId()).update("status","Approved","bloodBankID",String.valueOf(lstBloodBankID.get(spBloodBank.getSelectedItemPosition()))).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task5) {
                                                        if(task5.isSuccessful())
                                                        {
                                                            MailSender sender=new MailSender();
                                                            sender.sendMail("Blood Request Approval","This is to inform you that your Blood Request has been approved successfully",userID);
                                                            Log.i(TAG,"Blood Request Approved Successfully!!");
                                                            Toasty.success(context,"Blood Request Approved Sucessfully!!", Toast.LENGTH_SHORT).show();
                                                            notifyDataSetChanged();
                                                            dialog.dismiss();
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
        });

        holder.btnDenyRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fStore.collection("BloodRequest").document(getSnapshots().getSnapshot(position).getId()).update("status","Rejected").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toasty.error(context, "Blood Request Rejected", Toast.LENGTH_SHORT).show();
                        Log.i(TAG,"Blood request Rejected");
                        notifyDataSetChanged();
                    }
                });

            }
        });

        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public static class AdminApproveRequestViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvRecipientName,tvRecipientPhone,tvRecipientCity,tvRecipientBloodGroup;
        Button btnAcceptRequest,btnDenyRequest;
        CardView approveRequest;

        public AdminApproveRequestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRecipientName=itemView.findViewById(R.id.tvRecipientName1);
            tvRecipientPhone=itemView.findViewById(R.id.tvRecipientPhone1);
            tvRecipientBloodGroup=itemView.findViewById(R.id.tvRecipientBloodGroup1);
            tvRecipientCity=itemView.findViewById(R.id.tvRecipientCity1);
            btnAcceptRequest=itemView.findViewById(R.id.btnAcceptRequest);
            btnDenyRequest=itemView.findViewById(R.id.btnDenyRequest);
            approveRequest=itemView.findViewById(R.id.cardViewApproveRequest);
        }
    }

}
