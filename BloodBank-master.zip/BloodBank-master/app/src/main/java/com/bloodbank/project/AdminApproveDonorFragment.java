package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminApproveDonorFragment extends Fragment {
    private AdminApproveDonorRecyclerAdapter adapter;
    private RecyclerView approveDonorRecyclerView;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    int count = 0;
    Query query;

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        ViewGroup root= (ViewGroup) inflater.inflate(R.layout.fragment_admin_approve_donor,null);
        approveDonorRecyclerView = (RecyclerView)root.findViewById(R.id.Approve_Donor_List_RecyclerView);
        fStore.collection("User").whereEqualTo("donor",true).whereEqualTo("verifyDonor",false).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        count++;
                    }
                    if(count!=0)
                    {
                        query = fStore.collection("User").whereEqualTo("donor",true).whereEqualTo("verifyDonor",false);
                        FirestoreRecyclerOptions<User> custOpt = new FirestoreRecyclerOptions.Builder<User>().setQuery(query, User.class).build();
                        adapter=new AdminApproveDonorRecyclerAdapter(custOpt,getContext());
                        approveDonorRecyclerView.setAdapter(adapter);
                        approveDonorRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Donors Found!!");
                        approveDonorRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        approveDonorRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });
        return root;
    }
}