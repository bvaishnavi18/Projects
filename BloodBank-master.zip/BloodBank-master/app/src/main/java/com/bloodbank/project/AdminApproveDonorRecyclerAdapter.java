package com.bloodbank.project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import es.dmoral.toasty.Toasty;


public class AdminApproveDonorRecyclerAdapter extends FirestoreRecyclerAdapter<User, AdminApproveDonorRecyclerAdapter.AdminApproveDonorViewHolder> {
    private static final String TAG = AdminApproveDonorRecyclerAdapter.class.getSimpleName();
    Context context;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();

    public AdminApproveDonorRecyclerAdapter(@NonNull FirestoreRecyclerOptions<User> options,Context context) {
        super(options);
        this.context=context;
    }

    @NonNull
    @Override
    public AdminApproveDonorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_user_approval,parent,false);
        return new AdminApproveDonorRecyclerAdapter.AdminApproveDonorViewHolder(view);
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminApproveDonorViewHolder holder, int position, @NonNull User user) {
        String userID=getSnapshots().getSnapshot(position).getId();
        holder.tvDonorName.setText("User Name: "+user.getUserName());
        holder.tvDonorGender.setText("Gender: "+user.getGender());
        holder.tvDonorEmail.setText("User Email: "+user.getUserEmail());
        holder.tvDonorPhone.setText("Contact No: "+user.getPhoneNumber());
        holder.tvDonorBloodGroup.setText("Blood Group: "+user.getBloodGroup());
        holder.tvDonorStatus.setText("Donor Status: "+user.getGender());
        holder.btnUserApprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fStore.collection("User").document(userID).update("verifyDonor",true).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            MailSender sender=new MailSender();
                            sender.sendMail("BloodBank Donor Approval","This is to inform you that your DONOR REQUEST has been sent successfully",userID);
                            Toasty.success(context, "Donor Approved Sucessfully!!", Toast.LENGTH_SHORT).show();
                            //Toast.makeText(context, "Donor Approved Successfully!!", Toast.LENGTH_SHORT).show();
                            Log.i(TAG,"Donor Approved Sucessfully!!");
                            notifyDataSetChanged();

                        }
                    }
                });
            }
        });

        holder.btnUserDeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fStore.collection("User").document(getSnapshots().getSnapshot(position).getId()).update("donor",false).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            
                            Toasty.success(context, "Donor Denied Approval Sucessfully!!", Toast.LENGTH_SHORT).show();
                            //Toast.makeText(context, "Donor Denied Approval Sucessfully!!", Toast.LENGTH_SHORT).show();
                            Log.i(TAG,"Donor Denied Approval Sucessfully!!");
                            notifyDataSetChanged();
                        }
                    }
                });
            }
        });

        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public static class AdminApproveDonorViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvDonorName, tvDonorGender, tvDonorEmail, tvDonorPhone, tvDonorBloodGroup, tvDonorStatus;
        Button btnUserApprove,btnUserDeny;
        CardView UserLinLayout;
        public AdminApproveDonorViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvDonorName =(TextView)itemView.findViewById(R.id.tv_donor_name);
            tvDonorGender=(TextView)itemView.findViewById(R.id.tv_donor_gender);
            tvDonorEmail =(TextView)itemView.findViewById(R.id.tv_donor_email);
            tvDonorPhone =(TextView)itemView.findViewById(R.id.tv_donor_contact);
            tvDonorBloodGroup =(TextView)itemView.findViewById(R.id.tv_donor_blood_group);
            tvDonorStatus =(TextView)itemView.findViewById(R.id.tv_donor_donor_status);
            btnUserApprove=(Button)itemView.findViewById(R.id.btnUserApprove);
            btnUserDeny=(Button)itemView.findViewById(R.id.btnUserDeny);
            UserLinLayout =(CardView)itemView.findViewById(R.id.cardViewApproveUser);
        }
    }
}
