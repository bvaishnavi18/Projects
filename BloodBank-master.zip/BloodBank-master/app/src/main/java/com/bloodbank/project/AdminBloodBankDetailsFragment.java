package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import es.dmoral.toasty.Toasty;

public class AdminBloodBankDetailsFragment extends Fragment {
    private static final String TAG = AdminBloodBankDetailsFragment.class.getSimpleName();
    EditText etBloodBankName,etBloodBankEmail,etBloodBankPhone,etBloodBankAddress;
    EditText etBloodGroupAPos,etBloodGroupANeg,etBloodGroupBPos,etBloodGroupBNeg,etBloodGroupABPos,etBloodGroupABNeg,etBloodGroupOPos,etBloodGroupONeg;
    Button btnUpdateDetails,btnUpdateStock;
    String bloodBankID;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();

    public void onStart() {
        super.onStart();
        fStore.collection("BloodBank").document(bloodBankID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful())
                {
                    DocumentSnapshot docSnapshot=task.getResult();
                    etBloodBankName.setText(String.valueOf(docSnapshot.getString("bloodBankName")));
                    etBloodBankEmail.setText(String.valueOf(docSnapshot.getString("bloodBankEmail")));
                    etBloodBankPhone.setText(String.valueOf(docSnapshot.getString("bloodBankPhone")));
                    etBloodBankAddress.setText(String.valueOf(docSnapshot.getString("bloodBankAddress")));
                    fStore.collection("BloodStock").whereEqualTo("bloodBankID",bloodBankID).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task2) {
                            for(QueryDocumentSnapshot docSnapshot:task2.getResult())
                            {
                                switch(docSnapshot.getString("bloodGroup"))
                                {
                                    case "A+":
                                        etBloodGroupAPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "A-":
                                        etBloodGroupANeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "B+":
                                        etBloodGroupBPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "B-":
                                        etBloodGroupBNeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "AB+":
                                        etBloodGroupABPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "AB-":
                                        etBloodGroupABNeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "O+":
                                        etBloodGroupOPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                    case "O-":
                                        etBloodGroupONeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                        break;
                                }

                            }
                        }
                    });
                }
            }
        });

    }
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_blood_bank_details, null);
        Bundle result=getArguments();
        bloodBankID=result.getString("bloodBankID");
        //Connecting Elements with Variables
        etBloodBankName=root.findViewById(R.id.etBloodBankName2);
        etBloodBankEmail=root.findViewById(R.id.etBloodBankEmail2);
        etBloodBankPhone=root.findViewById(R.id.etBloodBankPhone2);
        etBloodBankAddress=root.findViewById(R.id.etBloodBankAddress2);
        etBloodGroupAPos=root.findViewById(R.id.etBloodGroupAPos);
        etBloodGroupANeg=root.findViewById(R.id.etBloodGroupANeg);
        etBloodGroupBPos=root.findViewById(R.id.etBloodGroupBPos);
        etBloodGroupBNeg=root.findViewById(R.id.etBloodGroupBNeg);
        etBloodGroupABPos=root.findViewById(R.id.etBloodGroupABPos);
        etBloodGroupABNeg=root.findViewById(R.id.etBloodGroupABNeg);
        etBloodGroupOPos=root.findViewById(R.id.etBloodGroupOPos);
        etBloodGroupONeg=root.findViewById(R.id.etBloodGroupONeg);
        btnUpdateDetails=root.findViewById(R.id.btnUpdateBloodBankDetails);
        btnUpdateStock=root.findViewById(R.id.btnUpdateBloodStock);


        btnUpdateDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    DocumentReference docReference=fStore.collection("BloodBank").document(bloodBankID);
                    docReference.update("bloodBankName",etBloodBankName.getText().toString());
                    docReference.update("bloodBankEmail",etBloodBankEmail.getText().toString());
                    docReference.update("bloodBankPhone",etBloodBankPhone.getText().toString());
                    docReference.update("bloodBankAddress",etBloodBankAddress.getText().toString()).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.i(TAG,"Blood Bank Details Updated Successfully!!!");
                            Toasty.success(getContext(), "Blood Bank Details Updated Successfully!!!", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG,e.getMessage());
                            Toasty.error(getContext(), "Failed to Update Blood Bank Details!!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toasty.error(getContext(), "Invalid Data", Toast.LENGTH_SHORT).show();
                }
            }
        });


        btnUpdateStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateStock())
                {
                    String[] bloodvalues = new String[] {"A+" , "A-" , "B+" , "B-" , "AB+" , "AB-" ,"O+" , "O-" };
                    for(int i=0;i<bloodvalues.length;i++)
                    {
                        switch(bloodvalues[i])
                        {
                            case "A+":
                                UpdateStock("A+");
                                break;
                            case "A-":
                                UpdateStock("A-");
                                break;
                            case "B+":
                                UpdateStock("B+");
                                break;
                            case "B-":
                                UpdateStock("B-");
                                break;
                            case "AB+":
                                UpdateStock("AB+");
                                break;
                            case "AB-":
                                UpdateStock("AB-");
                                break;
                            case "O+":
                                UpdateStock("O+");
                                break;
                            case "O-":
                                UpdateStock("O-");
                                break;
                        }
                    }
                    Toasty.success(getContext(), "Stock Updated Successfully!!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toasty.error(getContext(), "Invalid Stock Data!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return root;
    }
    public void UpdateStock(String bloodGroup)
    {
        fStore.collection("BloodStock").whereEqualTo("bloodBankID",bloodBankID).whereEqualTo("bloodGroup",bloodGroup).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                switch(bloodGroup)
                {
                    case "A+":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupAPos.getText().toString()));
                        break;
                    case "A-":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupANeg.getText().toString()));
                        break;
                    case "B+":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupBPos.getText().toString()));
                        break;
                    case "B-":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupBNeg.getText().toString()));
                        break;
                    case "AB+":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupABPos.getText().toString()));
                        break;
                    case "AB-":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupABNeg.getText().toString()));
                        break;
                    case "O+":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupOPos.getText().toString()));
                        break;
                    case "O-":
                        fStore.collection("BloodStock").document(value.getDocuments().get(0).getId()).update("bloodQuantity",Integer.valueOf(etBloodGroupONeg.getText().toString()));
                        break;
                }
            }
        });
    }

    public boolean ValidateStock()
    {
        Integer maxLimit=50;
        Boolean isStockValid=true;
        if(etBloodGroupAPos.getText().toString().equals("")||etBloodGroupANeg.getText().toString().equals("")||etBloodGroupBPos.getText().toString().equals("")||etBloodGroupBNeg.getText().toString().equals("")||etBloodGroupABPos.getText().toString().equals("")||etBloodGroupABNeg.getText().toString().equals("")||etBloodGroupOPos.getText().toString().equals("")||etBloodGroupONeg.getText().toString().equals(""))
        {
            isStockValid=false;
        }
        if(Integer.valueOf(etBloodGroupAPos.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupAPos.requestFocus();
            etBloodGroupAPos.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupANeg.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupANeg.requestFocus();
            etBloodGroupANeg.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupBPos.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupBPos.requestFocus();
            etBloodGroupBPos.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupBNeg.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupBNeg.requestFocus();
            etBloodGroupBNeg.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupABPos.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupABPos.requestFocus();
            etBloodGroupABPos.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupABNeg.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupABNeg.requestFocus();
            etBloodGroupABNeg.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupOPos.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupOPos.requestFocus();
            etBloodGroupOPos.setError("Stock Limit Exceeded");
        }
        if(Integer.valueOf(etBloodGroupONeg.getText().toString())>maxLimit)
        {
            isStockValid=false;
            etBloodGroupONeg.requestFocus();
            etBloodGroupONeg.setError("Stock Limit Exceeded");
        }
        return isStockValid;
    }
    public boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etBloodBankName.getText().toString().equals("")||etBloodBankEmail.getText().toString().equals("")||etBloodBankPhone.getText().toString().equals("")||etBloodBankAddress.getText().toString().equals(""))
        {
            isDataValid=false;
        }
        if(!(etBloodBankPhone.getText().toString().matches("[0-9]{10}"))){
            isDataValid=false;
            etBloodBankPhone.setError("Invalid Phone Number");
            etBloodBankPhone.requestFocus();
        }
        if(!(etBloodBankEmail.getText().toString().matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"))){
            isDataValid=false;
            etBloodBankEmail.setError("Invalid Email ID");
            etBloodBankEmail.requestFocus();
        }
        return isDataValid;
    }
}
/*if (docSnapshot.getString("bloodGroup").equals("A+")) {
                                    etBloodGroupAPos.setText(String.valueOf(docSnapshot.get("bloodQuantity", Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("A-")){
                                    etBloodGroupANeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("B+")){
                                    etBloodGroupBPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("B-")){
                                    etBloodGroupBNeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("AB+")){
                                    etBloodGroupABPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("AB-")){
                                    etBloodGroupABNeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("O+")){
                                    etBloodGroupOPos.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }
                                else if (docSnapshot.getString("bloodGroup").equals("O-")){
                                    etBloodGroupONeg.setText(String.valueOf(docSnapshot.get("bloodQuantity",Integer.TYPE)));
                                }*/