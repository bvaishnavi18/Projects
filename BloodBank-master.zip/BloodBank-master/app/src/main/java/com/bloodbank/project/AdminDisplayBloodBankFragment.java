package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminDisplayBloodBankFragment extends Fragment {
    private AdminDisplayBloodBankRecyclerAdapter adapter;
    private RecyclerView displayBloodBankRecyclerView;
    Button btnAddBankButton;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    int count = 0;
    Query query;
    Context context;

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_display_bloodbank, null);
        displayBloodBankRecyclerView = (RecyclerView)root.findViewById(R.id.Display_BloodBank_List_RecyclerView);
        btnAddBankButton=root.findViewById(R.id.btnAddBank1);
        fStore.collection("BloodBank").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        count++;
                    }
                    if(count!=0)
                    {
                        query = fStore.collection("BloodBank");
                        FirestoreRecyclerOptions<BloodBank> bloodBankOpt = new FirestoreRecyclerOptions.Builder<BloodBank>().setQuery(query, BloodBank.class).build();
                        adapter=new AdminDisplayBloodBankRecyclerAdapter(bloodBankOpt,getContext());
                        displayBloodBankRecyclerView.setAdapter(adapter);
                        displayBloodBankRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();
                        adapter.notifyDataSetChanged();

                        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
                            @Override
                            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                                return false;
                            }

                            @Override
                            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                                AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
                                dialog.setTitle("Delete Blood Bank");
                                dialog.setMessage("Are you sure you want to delete this Blood Bank?");
                                dialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        adapter.deleteBloodBank(viewHolder.getAdapterPosition());
                                    }
                                });
                                dialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        adapter.notifyDataSetChanged();
                                    }
                                });
                                AlertDialog alertDialog=dialog.create();
                                alertDialog.show();
                                adapter.notifyDataSetChanged();
                            }
                        }).attachToRecyclerView(displayBloodBankRecyclerView);
                        adapter.notifyDataSetChanged();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Blood Banks Found!!");
                        displayBloodBankRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayBloodBankRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }

        });
        btnAddBankButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                AdminAddBloodBankFragment newFragment=new AdminAddBloodBankFragment();
                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,newFragment).addToBackStack("addbloodbank").commit();
            }

        });
        return root;
    }
    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }

        return (Activity) context;
    }
}