package com.bloodbank.project;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;

import es.dmoral.toasty.Toasty;

public class AdminDisplayBloodBankRecyclerAdapter extends FirestoreRecyclerAdapter<BloodBank, AdminDisplayBloodBankRecyclerAdapter.AdminDispBloodBankViewHolder> {
    Context context;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    private static final String TAG=AdminDisplayBloodBankRecyclerAdapter.class.getSimpleName();

    public AdminDisplayBloodBankRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodBank> options, Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminDispBloodBankViewHolder holder, int position, @NonNull BloodBank bloodBank) {
        holder.tvBloodBankName.setText("Name: "+String.valueOf(bloodBank.getBloodBankName()));
        holder.tvBloodBankEmail.setText("Email: "+String.valueOf(bloodBank.getBloodBankEmail()));
        holder.tvBloodBankPhone.setText("Contact No: "+String.valueOf(bloodBank.getBloodBankPhone()));
        holder.tvBloodBankCity.setText("City: "+String.valueOf(bloodBank.getBloodBankCity()));
        holder.DispBloodBankLinLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                AdminBloodBankDetailsFragment newFragment = new AdminBloodBankDetailsFragment();
                Bundle result=new Bundle();
                result.putString("bloodBankID",getSnapshots().getSnapshot(position).getId());
                newFragment.setArguments(result);
                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,newFragment).addToBackStack("addbloodbank").commit();
            }
        });
    }
    public void deleteBloodBank(final int position)
    {
        fStore.collection("BloodStock").whereEqualTo("bloodBankID",getSnapshots().getSnapshot(position).getId()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful())
                {
                    for(QueryDocumentSnapshot docSnapshot:task.getResult())
                    {
                        fStore.collection("BloodStock").document(String.valueOf(docSnapshot.getId())).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task2) {
                                if(task2.isSuccessful())
                                {
                                    Log.i(TAG,"Deleted Blood Stock ID: "+docSnapshot.getId());
                                }
                            }
                        });
                    }
                    fStore.collection("BloodBank").document(String.valueOf(getSnapshots().getSnapshot(position).getId())).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toasty.success(context, "Deleted Blood Bank Successfully!!1", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }

        return (Activity) context;
    }

    @NonNull
    @Override
    public AdminDispBloodBankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_display_blood_bank,parent,false);
        return new AdminDisplayBloodBankRecyclerAdapter.AdminDispBloodBankViewHolder(view);
    }

    public static class AdminDispBloodBankViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvBloodBankName, tvBloodBankEmail, tvBloodBankPhone, tvBloodBankCity;
        CardView DispBloodBankLinLayout;
        public AdminDispBloodBankViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvBloodBankName =(TextView)itemView.findViewById(R.id.tvBloodBankName);
            tvBloodBankEmail =(TextView)itemView.findViewById(R.id.tvBloodBankEmail);
            tvBloodBankPhone =(TextView)itemView.findViewById(R.id.tvBloodBankPhone);
            tvBloodBankCity =(TextView)itemView.findViewById(R.id.tvBloodBankCity);
            DispBloodBankLinLayout =(CardView)itemView.findViewById(R.id.cardViewBloodBank);
        }
    }
}
