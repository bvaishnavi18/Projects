package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminDisplayBloodDriveFragment extends Fragment {
    AdminDisplayBloodDriveRecyclerAdapter adapter;
    RecyclerView displayBloodDriveRecyclerView;
    FirebaseFirestore firestore=FirebaseFirestore.getInstance();
    Button btnAddBloodDrive;
    int count=0;
    Query query;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_display_blood_drive, null);
        displayBloodDriveRecyclerView=root.findViewById(R.id.Display_BloodDrive_List_RecyclerView);
        btnAddBloodDrive=root.findViewById(R.id.btnAddBloodDrive);
    firestore.collection("BloodDrive").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
        @Override
        public void onComplete(@NonNull Task<QuerySnapshot> task) {
            if(task.isSuccessful())
            {
                for (QueryDocumentSnapshot snapshot : task.getResult())
                count++;
            }
            if (count!=0)
            {
                query=firestore.collection("BloodDrive");
                FirestoreRecyclerOptions<BloodDrive> recyclerOptions=new FirestoreRecyclerOptions.Builder<BloodDrive>().setQuery(query,BloodDrive.class).build();
                adapter=new AdminDisplayBloodDriveRecyclerAdapter(recyclerOptions,getContext());
                displayBloodDriveRecyclerView.setAdapter(adapter);
                displayBloodDriveRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                adapter.startListening();
                adapter.notifyDataSetChanged();

                new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
                        builder.setTitle("Delete Blood Drive");
                        builder.setMessage("Do you want to delete this blood drive?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                adapter.deleteDrive(viewHolder.getAdapterPosition());
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                adapter.notifyDataSetChanged();
                            }
                        });
                        AlertDialog dialog=builder.create();
                        dialog.show();
                        adapter.notifyDataSetChanged();
                    }
                }).attachToRecyclerView(displayBloodDriveRecyclerView);
                adapter.notifyDataSetChanged();
            }
            else
            {
                    EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyRecyclerAdapter=new EmptyRecyclerAdapter<>(getContext(),"No Blood Drives Found!!! \n Please press the below add button to add drive");
                    displayBloodDriveRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    displayBloodDriveRecyclerView.setAdapter(emptyRecyclerAdapter);
            }
        }
    });

        btnAddBloodDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                AdminAddBloodDriveFragment newFragment=new AdminAddBloodDriveFragment();
                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,newFragment).addToBackStack("addblooddrive").commit();
            }
        });
        return root;
    }

    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }

        return (Activity) context;
    }
}