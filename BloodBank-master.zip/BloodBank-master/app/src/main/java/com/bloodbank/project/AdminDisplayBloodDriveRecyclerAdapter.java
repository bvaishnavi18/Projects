package com.bloodbank.project;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import es.dmoral.toasty.Toasty;

//import es.dmoral.toasty.Toasty;

public class    AdminDisplayBloodDriveRecyclerAdapter extends FirestoreRecyclerAdapter<BloodDrive,AdminDisplayBloodDriveRecyclerAdapter.AdminDisplayBloodDriveViewHolder> {
    Context context;
    FirebaseFirestore fStore =FirebaseFirestore.getInstance();
    private static final String TAG=AdminDisplayBloodDriveRecyclerAdapter.class.getSimpleName();

    public AdminDisplayBloodDriveRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodDrive> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminDisplayBloodDriveViewHolder holder, int position, @NonNull BloodDrive bloodDrive) {
        holder.txtDriveName.setText("Drive Name : "+bloodDrive.getDriveName());
        holder.txtDriveVenue.setText("Drive Venue : "+bloodDrive.getDriveVenue());
        holder.txtDriveCity.setText("Drive City : "+bloodDrive.getDriveCity());
        holder.txtDriveContact.setText("Contact Number : "+bloodDrive.getDriveContactNo());
        holder.txtDriveDate.setText("Date : "+bloodDrive.getDriveDate());
        holder.txtDriveTime.setText("Timings: "+bloodDrive.getDriveStartTime()+" - "+bloodDrive.getDriveEndTime());
    }

    @NonNull
    @Override
    public AdminDisplayBloodDriveViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_display_drive,parent,false);
        return new AdminDisplayBloodDriveRecyclerAdapter.AdminDisplayBloodDriveViewHolder(view);
    }

    public static class AdminDisplayBloodDriveViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtDriveName,txtDriveVenue,txtDriveContact,txtDriveCity,txtDriveDate,txtDriveTime;
        CardView cdBloodDrive;
        public AdminDisplayBloodDriveViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDriveName=itemView.findViewById(R.id.txtDriveName);
            txtDriveVenue=itemView.findViewById(R.id.txtDriveVenue);
            txtDriveContact=itemView.findViewById(R.id.txtDriveContact);
            txtDriveCity=itemView.findViewById(R.id.txtDriveCity);
            txtDriveDate=itemView.findViewById(R.id.txtDriveDate);
            txtDriveTime=itemView.findViewById(R.id.txtDriveTime);
            cdBloodDrive=itemView.findViewById(R.id.cardViewDriveDetails);
        }
    }

    public void deleteDrive(final int position)
    {
        fStore.collection("BloodDrive").document(getSnapshots().getSnapshot(position).getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    Toasty.success(context, "Blood Drive Deleted Successfully!!", Toast.LENGTH_SHORT).show();
                   // Toast.makeText(context, "Blood Drive Deleted Successfully!!", Toast.LENGTH_SHORT).show();
                    Log.i(TAG,"Blood Drive Deleted Successfully!!!");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG,"Error: "+e.getMessage());
            }
        });
    }
}
