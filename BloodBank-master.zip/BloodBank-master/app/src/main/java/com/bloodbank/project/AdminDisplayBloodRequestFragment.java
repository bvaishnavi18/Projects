package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminDisplayBloodRequestFragment extends Fragment {
    private RecyclerView displayBloodRequestRecyclerView;
    private AdminDisplayBloodRequestRecyclerAdapter adapter;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    Button btnApproveBloodRequest;
    int count=0;
    Query query;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_display_blood_request, null);
            displayBloodRequestRecyclerView =(RecyclerView) root.findViewById(R.id.Display_Blood_Request_RecyclerView);
            btnApproveBloodRequest=(Button)root.findViewById(R.id.btnApproveBloodRequest);

            btnApproveBloodRequest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AppCompatActivity activity = (AppCompatActivity) unwrap(view.getContext());
                    AdminApproveBloodRequestFragment newFragment=new AdminApproveBloodRequestFragment();
                    activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,newFragment).addToBackStack("addblooddrive").commit();
                }
            });

            fStore.collection("BloodRequest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful())
                    {
                       for (QueryDocumentSnapshot documentSnapshot:task.getResult()) {
                           count++;
                       }
                       if (count!=0)
                       {
                           query=fStore.collection("BloodRequest");
                           FirestoreRecyclerOptions<BloodRequest> reqOpt=new FirestoreRecyclerOptions.Builder<BloodRequest>().setQuery(query,BloodRequest.class).build();
                           adapter=new AdminDisplayBloodRequestRecyclerAdapter(reqOpt,getContext());
                           displayBloodRequestRecyclerView.setAdapter(adapter);
                           displayBloodRequestRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                           adapter.startListening();

                       }
                       else {

                           EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyRecyclerAdapter=new EmptyRecyclerAdapter<>(getContext(),"No Blood Request Found");
                           displayBloodRequestRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                           displayBloodRequestRecyclerView.setAdapter(emptyRecyclerAdapter);
                       }
                    }
                }
            });
        return root;
    }
    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }

        return (Activity) context;
    }
}
