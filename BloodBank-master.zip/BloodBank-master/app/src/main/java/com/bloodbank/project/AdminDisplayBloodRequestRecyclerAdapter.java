package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class AdminDisplayBloodRequestRecyclerAdapter extends FirestoreRecyclerAdapter<BloodRequest,AdminDisplayBloodRequestRecyclerAdapter.AdminDisplayBloodRequestViewHolder> {
    Context context;

    public AdminDisplayBloodRequestRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodRequest> options,Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminDisplayBloodRequestViewHolder holder, int position, @NonNull BloodRequest bloodRequest) {
        holder.tvRecipientName.setText("Name: "+bloodRequest.getRecipientName());
        holder.tvRecipientPhone.setText("Phone Number: "+bloodRequest.getRecipientPhone());
        holder.tvRecipientCity.setText("City: "+bloodRequest.getRecipientCity());
        holder.tvRecipientBloodGroup.setText("Blood Group: "+bloodRequest.getRecipientBloodGroup());
    }

    @NonNull
    @Override
    public AdminDisplayBloodRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_admin_display_blood_request,parent,false);
        return new AdminDisplayBloodRequestRecyclerAdapter.AdminDisplayBloodRequestViewHolder(view);
    }

    public  static  class AdminDisplayBloodRequestViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvRecipientName,tvRecipientPhone,tvRecipientCity,tvRecipientBloodGroup;
        CardView approveRequest;
        public AdminDisplayBloodRequestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRecipientName=itemView.findViewById(R.id.tvRecipientName2);
            tvRecipientPhone=itemView.findViewById(R.id.tvRecipientPhone2);
            tvRecipientBloodGroup=itemView.findViewById(R.id.tvRecipientBloodGroup2);
            tvRecipientCity=itemView.findViewById(R.id.tvRecipientCity2);
            approveRequest=itemView.findViewById(R.id.cardViewApproveRequest2);
        }
    }
}
