package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminDisplayDonorsFragment extends Fragment {
    private AdminDisplayDonorRecyclerAdapter adapter;
    private RecyclerView displayDonorRecyclerView;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    Button btnApproveDonor;
    int count = 0;
    Query query;

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_display_donors, null);
        displayDonorRecyclerView = (RecyclerView)root.findViewById(R.id.Display_Donor_List_RecyclerView);
        btnApproveDonor=(Button)root.findViewById(R.id.btnApproveDonor);

        btnApproveDonor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity= (AppCompatActivity) unwrap(view.getContext());
                AdminApproveDonorFragment registrationFragment=new AdminApproveDonorFragment();
                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_admin_container,registrationFragment).addToBackStack("Registration").commit();
            }
        });

        fStore.collection("User").whereEqualTo("donor",true).whereEqualTo("verifyDonor",true).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        count++;
                    }
                    if(count!=0)
                    {
                        query = fStore.collection("User").whereEqualTo("donor",true).whereEqualTo("verifyDonor",true);
                        FirestoreRecyclerOptions<User> custOpt = new FirestoreRecyclerOptions.Builder<User>().setQuery(query, User.class).build();
                        adapter=new AdminDisplayDonorRecyclerAdapter(custOpt,getContext());
                        displayDonorRecyclerView.setAdapter(adapter);
                        displayDonorRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();
                        adapter.notifyDataSetChanged();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Users Found!!");
                        displayDonorRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayDonorRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });
        return root;
    }
    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }
        return (Activity) context;
    }
}