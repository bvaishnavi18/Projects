package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;

import static com.bloodbank.project.R.id.drawer_email;
import static com.bloodbank.project.R.id.drawer_name;

public class AdminHomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG= AdminHomeActivity.class.getSimpleName();
    private DrawerLayout drawer;
    private final FirebaseAuth fAuth=FirebaseAuth.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer=findViewById(R.id.drawer_layout);
        final NavigationView navigationView =findViewById(R.id.nav_admin_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(AdminHomeActivity.this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        if(savedInstanceState==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container, new AdminHomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_admin_home);
        }
        FirebaseUser user = fAuth.getCurrentUser();
        String EmailID=user.getEmail();
        String Name="Administrator";
        View headerView=navigationView.getHeaderView(0);
        TextView txtEmail=(TextView)headerView.findViewById(drawer_email);
        txtEmail.setText(EmailID);
        TextView txtDrawerName=(TextView)headerView.findViewById(drawer_name);
        txtDrawerName.setText(Name);

        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if(task.isSuccessful())
                {
                    String token=task.getResult();
                    Log.v(TAG,"Token ID: "+token);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {

        if(drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            //super.onBackPressed();
            if(getFragmentManager().getBackStackEntryCount() <= 1){
                super.onBackPressed();
            } else {
                getFragmentManager().popBackStack();
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId())
        {
            case R.id.nav_admin_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminHomeFragment()).commit();
                break;
            case R.id.nav_disp_blood_bank:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminDisplayBloodBankFragment()).commit();
                break;
            case R.id.nav_donors:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminDisplayDonorsFragment()).commit();
                break;
            case R.id.nav_blood_request:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminDisplayBloodRequestFragment()).commit();
                break;
            case R.id.nav_all_users:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminUserDetailsFragment()).commit();
                break;
            case R.id.nav_add_blood_drive:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminDisplayBloodDriveFragment()).commit();
                break;
            case R.id.nav_approve_donors:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_admin_container,new AdminApproveDonationFragment()).commit();
                break;
            case R.id.nav_sign_out:
                FirebaseAuth.getInstance().signOut();
                Intent signoutintent = new Intent(AdminHomeActivity.this,LoginActivity.class);
                startActivity(signoutintent);
                finish();
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}