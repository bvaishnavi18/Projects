package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import java.util.List;

public class AdminHomeDisplayStockRecyclerAdapter extends RecyclerView.Adapter<AdminHomeDisplayStockRecyclerAdapter.AdminHomeDisplayStockViewHolder> {
    Context context;
    public List<BloodStock> lstBloodStock;
    public AdminHomeDisplayStockRecyclerAdapter(Context context, List<BloodStock> lstBloodStock) {
        this.context=context;
        this.lstBloodStock=lstBloodStock;
    }

    @NonNull
    @Override
    public AdminHomeDisplayStockViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_blood_group_stock,parent,false);
        return new AdminHomeDisplayStockRecyclerAdapter.AdminHomeDisplayStockViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminHomeDisplayStockViewHolder holder, int position) {
        holder.tvBloodGroup.setText(String.valueOf(lstBloodStock.get(position).getBloodGroup()));
        holder.tvBloodStock.setText("Stock: "+String.valueOf(lstBloodStock.get(position).getBloodQuantity()));
    }

    @Override
    public int getItemCount() {
        if(lstBloodStock!=null){
            return lstBloodStock.size();
        }
        else
        {
            return 0;
        }
    }

    public static class AdminHomeDisplayStockViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvBloodGroup, tvBloodStock;
        CardView BloodStockLinLayout;
        public AdminHomeDisplayStockViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvBloodGroup =(TextView)itemView.findViewById(R.id.tv_display_stock_group);
            tvBloodStock=(TextView)itemView.findViewById(R.id.tv_display_stock_quantity);
            BloodStockLinLayout =(CardView)itemView.findViewById(R.id.display_bloodstock_cardview);
        }
    }
}
