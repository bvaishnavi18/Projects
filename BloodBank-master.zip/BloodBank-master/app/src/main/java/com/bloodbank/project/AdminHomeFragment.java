package com.bloodbank.project;

import android.os.Build;
import android.os.Bundle;
import android.util.ArrayMap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.security.cert.CollectionCertStoreParameters;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminHomeFragment extends Fragment {
    private static final String TAG=AdminHomeFragment.class.getSimpleName();
    private RecyclerView displayBloodStockRecyclerView;
    private AdminHomeDisplayStockRecyclerAdapter adapter;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    TextView tvTotalDonors,tvTotalDonatedToday,tvTodayRequest,tvTodayApproveReq;
    TextView tvHeading,tvDashboardHeading;
    private List<BloodStock> lstBloodStock;
    private HashMap<String,Integer> lstStock;
    Integer curQuant,newQuant;
    String strCurDate;
    int count=0;
    @RequiresApi(api = Build.VERSION_CODES.O)
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_home, null);
        displayBloodStockRecyclerView =(RecyclerView) root.findViewById(R.id.Admin_Display_Stock_RecyclerView);
        tvTotalDonors=(TextView)root.findViewById(R.id.tvDashboardTotalDonors);
        tvTotalDonatedToday=(TextView)root.findViewById(R.id.tvDashboardDonatedToday);
        tvTodayRequest=(TextView)root.findViewById(R.id.tvDashboardTodayRequest);
        tvTodayApproveReq=(TextView)root.findViewById(R.id.tvDashboardTodayApproveRequest);
        tvHeading=(TextView)root.findViewById(R.id.textView11);
        tvDashboardHeading=(TextView)root.findViewById(R.id.textView12);

        tvTotalDonors.setVisibility(View.GONE);
        tvTotalDonatedToday.setVisibility(View.GONE);
        tvTodayRequest.setVisibility(View.GONE);
        tvTodayApproveReq.setVisibility(View.GONE);
        tvHeading.setVisibility(View.GONE);
        tvDashboardHeading.setVisibility(View.GONE);
        fStore.collection("BloodStock").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful())
                {
                    lstStock=new HashMap<>();
                    lstBloodStock=new ArrayList<>();
                    for (QueryDocumentSnapshot documentSnapshot:task.getResult()) {
                        if(!lstStock.containsKey(documentSnapshot.getString("bloodGroup")))
                        {
                            lstStock.put(String.valueOf(documentSnapshot.getString("bloodGroup")),Integer.valueOf(documentSnapshot.get("bloodQuantity",Integer.TYPE)));
                            count++;
                        }
                        else
                        {
                            curQuant=Integer.valueOf(lstStock.get(documentSnapshot.getString("bloodGroup")));
                            newQuant=Integer.valueOf(curQuant)+Integer.valueOf(documentSnapshot.get("bloodQuantity",Integer.TYPE));
                            lstStock.replace(String.valueOf(documentSnapshot.getString("bloodGroup")),Integer.valueOf(curQuant),Integer.valueOf(newQuant));
                        }
                    }
                    if (count!=0)
                    {
                        for(Map.Entry<String,Integer> e: lstStock.entrySet())
                        {
                            BloodStock bloodStock=new BloodStock();
                            bloodStock.setBloodGroup(e.getKey());
                            bloodStock.setBloodQuantity(e.getValue());
                            lstBloodStock.add(bloodStock);
                            adapter=new AdminHomeDisplayStockRecyclerAdapter(getContext(),lstBloodStock);
                            displayBloodStockRecyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
                            displayBloodStockRecyclerView.setAdapter(adapter);
                        }
                    }
                    else {

                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyRecyclerAdapter=new EmptyRecyclerAdapter<>(getContext(),"No Blood Stock Found");
                        displayBloodStockRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayBloodStockRecyclerView.setAdapter(emptyRecyclerAdapter);
                    }
                }
            }
        });

        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime localDateTime = LocalDateTime.now();
        strCurDate=localDateTime.format(dateFormat);

        tvHeading.setVisibility(View.VISIBLE);
        tvDashboardHeading.setVisibility(View.VISIBLE);
        fStore.collection("User").whereEqualTo("donor",true).whereEqualTo("verifyDonor",true).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task1) {
                if(task1.isSuccessful())
                {
                    tvTotalDonors.setVisibility(View.VISIBLE);
                    tvTotalDonors.setText("Total Donors: "+String.valueOf(task1.getResult().size()));
                    fStore.collection("BloodDonation").whereEqualTo("donationDate",strCurDate).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task2) {
                            if(task2.isSuccessful())
                            {
                                tvTotalDonatedToday.setVisibility(View.VISIBLE);
                                tvTotalDonatedToday.setText("Total Donated Today: "+String.valueOf(task2.getResult().size()));
                                fStore.collection("BloodRequest").whereEqualTo("requestDate",strCurDate).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task3) {
                                        if(task3.isSuccessful())
                                        {
                                            tvTodayRequest.setVisibility(View.VISIBLE);
                                            tvTodayRequest.setText("Today's Request: "+String.valueOf(task3.getResult().size()));
                                            fStore.collection("BloodRequest").whereEqualTo("requestDate",strCurDate).whereEqualTo("status","Approved").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<QuerySnapshot> task4) {
                                                    if(task4.isSuccessful())
                                                    {
                                                        tvTodayApproveReq.setVisibility(View.VISIBLE);
                                                        tvTodayApproveReq.setText("Today's Approved Request: "+String.valueOf(task4.getResult().size()));
                                                    }
                                                }
                                            });
                                        }
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
        return root;
    }
}