package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdminUserDetailsFragment extends Fragment {
    private AdminUserDetailsRecyclerAdapter adapter;
    private RecyclerView displayUserRecyclerView;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    int count = 0;
    Query query;

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_admin_user_details, null);
        displayUserRecyclerView = (RecyclerView)root.findViewById(R.id.Display_User_List_RecyclerView);
        fStore.collection("User").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        count++;
                    }
                    if(count!=0)
                    {
                        query = fStore.collection("User");
                        FirestoreRecyclerOptions<User> custOpt = new FirestoreRecyclerOptions.Builder<User>().setQuery(query, User.class).build();
                        adapter=new AdminUserDetailsRecyclerAdapter(custOpt,getContext());
                        displayUserRecyclerView.setAdapter(adapter);
                        displayUserRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();
                        adapter.notifyDataSetChanged();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Users Found!!");
                        displayUserRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayUserRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });
        return root;
    }
}