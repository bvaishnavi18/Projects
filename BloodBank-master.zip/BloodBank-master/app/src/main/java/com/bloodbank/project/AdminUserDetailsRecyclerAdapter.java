package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class AdminUserDetailsRecyclerAdapter extends FirestoreRecyclerAdapter<User, AdminUserDetailsRecyclerAdapter.AdminUserDetailsViewHolder> {
    Context context;

    public AdminUserDetailsRecyclerAdapter(@NonNull FirestoreRecyclerOptions<User> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AdminUserDetailsViewHolder holder, int position, @NonNull User user) {
        holder.tvUserName.setText(" User Name: "+String.valueOf(user.getUserName()));
        holder.tvUserEmail.setText(" User Email: "+String.valueOf(user.getUserEmail()));
        holder.tvUserPhone.setText(" Contact No: "+String.valueOf(user.getPhoneNumber()));
        holder.tvBloodGroup.setText(" Blood Group: "+String.valueOf(user.getBloodGroup()));
        if(user.getDonor().equals(true))
        {
            holder.tv_isDonor.setText(" User Status: "+"Donor");
        }
        else
        {
            holder.tv_isDonor.setText(" User Status: "+"Not a Donor");
        }
    }

    @NonNull
    @Override
    public AdminUserDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_user_details,parent,false);
        return new AdminUserDetailsRecyclerAdapter.AdminUserDetailsViewHolder(view);
    }

    public static class AdminUserDetailsViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvUserName,tvUserEmail,tvUserPhone,tvBloodGroup,tv_isDonor;
        CardView UserLinLayout;
        public AdminUserDetailsViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvUserName=(TextView)itemView.findViewById(R.id.tv_user_details_name);
            tvUserEmail=(TextView)itemView.findViewById(R.id.tv_user_details_email);
            tvUserPhone=(TextView)itemView.findViewById(R.id.tv_user_details_phone);
            tvBloodGroup=(TextView)itemView.findViewById(R.id.tv_user_details_bloodgroup);
            tv_isDonor=(TextView)itemView.findViewById(R.id.tv_user_details_donor);
            UserLinLayout =(CardView)itemView.findViewById(R.id.cardViewUserDetails);
        }
    }
}
