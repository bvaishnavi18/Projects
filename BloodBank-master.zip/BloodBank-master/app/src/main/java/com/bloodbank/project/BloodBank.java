package com.bloodbank.project;

public class BloodBank {
    private String bloodBankName;
    private String bloodBankEmail;
    private String bloodBankPhone;
    private String bloodBankCity;
    private String bloodBankAddress;

    public BloodBank() {
    }

    public String getBloodBankName() {
        return bloodBankName;
    }

    public void setBloodBankName(String bloodBankName) {
        this.bloodBankName = bloodBankName;
    }

    public String getBloodBankEmail() {
        return bloodBankEmail;
    }

    public void setBloodBankEmail(String bloodBankEmail) {
        this.bloodBankEmail = bloodBankEmail;
    }

    public String getBloodBankPhone() {
        return bloodBankPhone;
    }

    public void setBloodBankPhone(String bloodBankPhone) {
        this.bloodBankPhone = bloodBankPhone;
    }

    public String getBloodBankCity() {
        return bloodBankCity;
    }

    public void setBloodBankCity(String bloodBankCity) {
        this.bloodBankCity = bloodBankCity;
    }

    public String getBloodBankAddress() {
        return bloodBankAddress;
    }

    public void setBloodBankAddress(String bloodBankAddress) {
        this.bloodBankAddress = bloodBankAddress;
    }
}
