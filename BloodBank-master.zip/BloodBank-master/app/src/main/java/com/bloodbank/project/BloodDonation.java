package com.bloodbank.project;

public class BloodDonation {
    private String userID;
    private String bloodGroup;
    private String donationDate;
    private Long donationTimeStamp;
    private String donationType;
    private String bloodBankID;
    private String bloodDriveID;
    private String donationStatus;

    public BloodDonation() {
    }

    public String getDonationStatus() {
        return donationStatus;
    }

    public void setDonationStatus(String donationStatus) {
        this.donationStatus = donationStatus;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(String donationDate) {
        this.donationDate = donationDate;
    }

    public Long getDonationTimeStamp() {
        return donationTimeStamp;
    }

    public void setDonationTimeStamp(Long donationTimeStamp) {
        this.donationTimeStamp = donationTimeStamp;
    }

    public String getDonationType() {
        return donationType;
    }

    public void setDonationType(String donationType) {
        this.donationType = donationType;
    }

    public String getBloodBankID() {
        return bloodBankID;
    }

    public void setBloodBankID(String bloodBankID) {
        this.bloodBankID = bloodBankID;
    }

    public String getBloodDriveID() {
        return bloodDriveID;
    }

    public void setBloodDriveID(String bloodDriveID) {
        this.bloodDriveID = bloodDriveID;
    }
}
