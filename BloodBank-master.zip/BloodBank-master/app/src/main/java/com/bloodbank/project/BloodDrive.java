package com.bloodbank.project;

public class BloodDrive {
    public String driveName;
    public String driveContactNo;
    public String driveVenue;
    public String bloodBankID;
    public String driveCity;
    public String driveDate;
    public String driveStartTime;
    public String driveEndTime;
    public Long driveStartTimeStamp;
    public Long driveEndTimeStamp;

    public BloodDrive() {
    }

    public String getDriveName() {
        return driveName;
    }

    public void setDriveName(String driveName) {
        this.driveName = driveName;
    }

    public String getDriveContactNo() {
        return driveContactNo;
    }

    public void setDriveContactNo(String driveContactNo) {
        this.driveContactNo = driveContactNo;
    }

    public String getDriveVenue() {
        return driveVenue;
    }

    public void setDriveVenue(String driveVenue) {
        this.driveVenue = driveVenue;
    }

    public String getBloodBankID() {
        return bloodBankID;
    }

    public void setBloodBankID(String bloodBankID) {
        this.bloodBankID = bloodBankID;
    }

    public String getDriveCity() {
        return driveCity;
    }

    public void setDriveCity(String driveCity) {
        this.driveCity = driveCity;
    }

    public String getDriveDate() {
        return driveDate;
    }

    public void setDriveDate(String driveDate) {
        this.driveDate = driveDate;
    }

    public String getDriveStartTime() {
        return driveStartTime;
    }

    public void setDriveStartTime(String driveStartTime) {
        this.driveStartTime = driveStartTime;
    }

    public String getDriveEndTime() {
        return driveEndTime;
    }

    public void setDriveEndTime(String driveEndTime) {
        this.driveEndTime = driveEndTime;
    }

    public Long getDriveStartTimeStamp() {
        return driveStartTimeStamp;
    }

    public void setDriveStartTimeStamp(Long driveStartTimeStamp) {
        this.driveStartTimeStamp = driveStartTimeStamp;
    }

    public Long getDriveEndTimeStamp() {
        return driveEndTimeStamp;
    }

    public void setDriveEndTimeStamp(Long driveEndTimeStamp) {
        this.driveEndTimeStamp = driveEndTimeStamp;
    }
}
