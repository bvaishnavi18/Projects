package com.bloodbank.project;

public class BloodRequest {
    public String recipientName;
    public Long recipientPhone;
    public String recipientCity;
    public String recipientBloodGroup;
    public String userID;
    public Long requestTimeStamp;
    public String requestDate;
    public String bloodBankID;
    public String status;

    public String getBloodBankID() {
        return bloodBankID;
    }

    public void setBloodBankID(String bloodBankID) {
        this.bloodBankID = bloodBankID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BloodRequest() {
    }

    public Long getRequestTimeStamp() {
        return requestTimeStamp;
    }

    public void setRequestTimeStamp(Long requestTimeStamp) {
        this.requestTimeStamp = requestTimeStamp;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public Long getRecipientPhone() {
        return recipientPhone;
    }

    public void setRecipientPhone(Long recipientPhone) {
        this.recipientPhone = recipientPhone;
    }

    public String getRecipientCity() {
        return recipientCity;
    }

    public void setRecipientCity(String recipientCity) {
        this.recipientCity = recipientCity;
    }

    public String getRecipientBloodGroup() {
        return recipientBloodGroup;
    }

    public void setRecipientBloodGroup(String recipientBloodGroup) {
        this.recipientBloodGroup = recipientBloodGroup;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
