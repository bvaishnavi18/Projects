package com.bloodbank.project;

public class BloodStock {
    private String bloodBankID;
    private String bloodGroup;
    private Integer bloodQuantity;

    public BloodStock() {
    }

    public String getBloodBankID() {
        return bloodBankID;
    }

    public void setBloodBankID(String bloodBankID) {
        this.bloodBankID = bloodBankID;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Integer getBloodQuantity() {
        return bloodQuantity;
    }

    public void setBloodQuantity(Integer bloodQuantity) {
        this.bloodQuantity = bloodQuantity;
    }
}
