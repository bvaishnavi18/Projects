package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class ContactUsFragment extends Fragment {
    Button btnCall,btnEmail;
    EditText etQuery;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_contact_us, null);
        btnCall=root.findViewById(R.id.btnCallUs);
        btnEmail=root.findViewById(R.id.btnEmailUs);
        etQuery=root.findViewById(R.id.etQuery);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Phone=new Intent(Intent.ACTION_VIEW, Uri.parse("tel:+918237860574"));
                startActivity(Phone);
            }
        });
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent email=new Intent(Intent.ACTION_SEND);
                email.putExtra(Intent.EXTRA_EMAIL,new String[]{"rajanipankaj11@gmail.com"});
                email.putExtra(Intent.EXTRA_SUBJECT,"Queries for Blood Bank");
                email.putExtra(Intent.EXTRA_TEXT,etQuery.getText().toString());
                email.setType("message/rfc822");
                startActivity(Intent.createChooser(email,"Select the Mail app"));
            }
        });
        return root;
    }
}