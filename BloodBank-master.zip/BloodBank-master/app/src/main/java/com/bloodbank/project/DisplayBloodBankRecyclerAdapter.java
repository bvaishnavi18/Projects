package com.bloodbank.project;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import es.dmoral.toasty.Toasty;

public class DisplayBloodBankRecyclerAdapter extends FirestoreRecyclerAdapter<BloodBank,DisplayBloodBankRecyclerAdapter.DisplayBloodBankViewHolder> {
    private static final String TAG=DisplayBloodBankRecyclerAdapter.class.getSimpleName();
    Context context;
    String bloodBankID,strCurDate;
    FirebaseAuth fAuth=FirebaseAuth.getInstance();
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();

    public DisplayBloodBankRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodBank> options,Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull DisplayBloodBankViewHolder holder, int position, @NonNull BloodBank bloodBank) {
        holder.tvBloodBankName.setText("Name: "+String.valueOf(bloodBank.getBloodBankName()));
        holder.tvBloodBankEmail.setText("Email: "+String.valueOf(bloodBank.getBloodBankEmail()));
        holder.tvBloodBankPhone.setText("Contact No: "+String.valueOf(bloodBank.getBloodBankPhone()));
        holder.tvBloodBankCity.setText("City: "+String.valueOf(bloodBank.getBloodBankCity()));
        holder.DispBloodBankLinLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(context);
                dialog.setTitle("Donate Confirmation");
                dialog.setMessage("Are you sure you donate blood to "+String.valueOf(bloodBank.getBloodBankName()));
                dialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        fStore.collection("User").document(fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                                if(task1.isSuccessful())
                                {
                                    DocumentSnapshot docSnapshot1=task1.getResult();
                                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                                    LocalDateTime localDateTime = LocalDateTime.now();
                                    String strCurTime = localDateTime.format(dateTimeFormatter);
                                    strCurDate=localDateTime.format(dateFormat);
                                    Timestamp curTimeStamp = Timestamp.valueOf(strCurTime);
                                    final Long curStampVal = curTimeStamp.getTime();

                                    BloodDonation bloodDonation=new BloodDonation();
                                    bloodDonation.setUserID(String.valueOf(fAuth.getCurrentUser().getUid()));
                                    bloodDonation.setBloodGroup(String.valueOf(docSnapshot1.getString("bloodGroup")));
                                    bloodDonation.setDonationDate(strCurDate);
                                    bloodDonation.setDonationTimeStamp(curStampVal);
                                    bloodDonation.setDonationType(String.valueOf("BloodBank"));
                                    bloodDonation.setDonationStatus("Pending");
                                    //To Be removed later
                                    bloodDonation.setBloodDriveID(null);
                                    bloodDonation.setBloodBankID(String.valueOf(getSnapshots().getSnapshot(position).getId()));
                                    fStore.collection("BloodDonation").add(bloodDonation).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentReference> task2) {
                                            if(task2.isSuccessful())
                                            {
                                                Toasty.success(context, "Registered to Blood Bank Sucessfully!!", Toast.LENGTH_SHORT).show();
                                                Log.i(TAG,"Registered to Blood Bank Sucessfully!!");
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toasty.error(context, "Failed to Register to Blood Bank!!", Toast.LENGTH_SHORT).show();
                                            Log.e(TAG,e.getMessage());
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
                dialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog=dialog.create();
                alertDialog.show();
            }
        });
    }

    @NonNull
    @Override
    public DisplayBloodBankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_display_blood_bank,parent,false);
        return new DisplayBloodBankRecyclerAdapter.DisplayBloodBankViewHolder(view);
    }

    public static class DisplayBloodBankViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvBloodBankName, tvBloodBankEmail, tvBloodBankPhone, tvBloodBankCity;
        CardView DispBloodBankLinLayout;
        public DisplayBloodBankViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvBloodBankName =(TextView)itemView.findViewById(R.id.tvBloodBankName);
            tvBloodBankEmail =(TextView)itemView.findViewById(R.id.tvBloodBankEmail);
            tvBloodBankPhone =(TextView)itemView.findViewById(R.id.tvBloodBankPhone);
            tvBloodBankCity =(TextView)itemView.findViewById(R.id.tvBloodBankCity);
            DispBloodBankLinLayout =(CardView)itemView.findViewById(R.id.cardViewBloodBank);
        }
    }
}
