package com.bloodbank.project;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class DisplayBloodDriveRecyclerAdapter extends FirestoreRecyclerAdapter<BloodDrive,DisplayBloodDriveRecyclerAdapter.DisplayBloodDriveViewHolder> {
    Context context;


    public DisplayBloodDriveRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodDrive> options,Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull DisplayBloodDriveViewHolder holder, int position, @NonNull BloodDrive bloodDrive) {
        holder.txtDriveName.setText("Drive Name : "+bloodDrive.getDriveName());
        holder.txtDriveVenue.setText("Drive Venue : "+bloodDrive.getDriveVenue());
        holder.txtDriveCity.setText("Drive City : "+bloodDrive.getDriveCity());
        holder.txtDriveContact.setText("Contact Number : "+bloodDrive.getDriveContactNo());
        holder.txtDriveDate.setText("Date : "+bloodDrive.getDriveDate());
        holder.txtDriveTime.setText("Timings: "+bloodDrive.getDriveStartTime()+" - "+bloodDrive.getDriveEndTime());
        holder.cdBloodDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity= (AppCompatActivity) unwrap(view.getContext());
                DisplayDriveDetailsFragment registrationFragment=new DisplayDriveDetailsFragment();
                Bundle bundle=new Bundle();
                bundle.putString("bloodDriveID",getSnapshots().getSnapshot(position).getId());
                bundle.putString("bloodBankID",String.valueOf(bloodDrive.getBloodBankID()));
                registrationFragment.setArguments(bundle);
                activity.getSupportFragmentManager().beginTransaction().add(R.id.fragment_user_container,registrationFragment).addToBackStack("Registration").commit();
            }
        });
    }

    @NonNull
    @Override
    public DisplayBloodDriveViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_display_drive,parent,false);
        return new DisplayBloodDriveRecyclerAdapter.DisplayBloodDriveViewHolder(view);
    }
    private static Activity unwrap(Context context) {
        while (!(context instanceof Activity) && context instanceof ContextWrapper) {
            context = ((ContextWrapper) context).getBaseContext();
        }
        return (Activity) context;
    }

    public static class DisplayBloodDriveViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtDriveName,txtDriveVenue,txtDriveContact,txtDriveCity,txtDriveDate,txtDriveTime;
        CardView cdBloodDrive;
        public DisplayBloodDriveViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDriveName=itemView.findViewById(R.id.txtDriveName);
            txtDriveVenue=itemView.findViewById(R.id.txtDriveVenue);
            txtDriveContact=itemView.findViewById(R.id.txtDriveContact);
            txtDriveCity=itemView.findViewById(R.id.txtDriveCity);
            txtDriveDate=itemView.findViewById(R.id.txtDriveDate);
            txtDriveTime=itemView.findViewById(R.id.txtDriveTime);
            cdBloodDrive=itemView.findViewById(R.id.cardViewDriveDetails);
        }
    }
}
