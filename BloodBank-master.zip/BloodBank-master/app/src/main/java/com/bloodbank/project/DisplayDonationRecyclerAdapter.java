package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class DisplayDonationRecyclerAdapter extends FirestoreRecyclerAdapter<BloodDonation,DisplayDonationRecyclerAdapter.DisplayDonationViewHolder> {
    Context context;
    FirebaseAuth fAuth=FirebaseAuth.getInstance();
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();

    public DisplayDonationRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodDonation> options,Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull DisplayDonationViewHolder holder, int position, @NonNull BloodDonation bloodDonation) {
        fStore.collection("User").document(String.valueOf(bloodDonation.getUserID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                if(task1.isSuccessful())
                {
                    DocumentSnapshot docSnapshot1=task1.getResult();
                    fStore.collection("BloodBank").document(String.valueOf(bloodDonation.getBloodBankID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task2) {
                            if(task2.isSuccessful())
                            {
                                DocumentSnapshot docSnapshot2=task2.getResult();
                                holder.tvDonorName.setText("Name: "+String.valueOf(docSnapshot1.getString("userName")));
                                holder.tvDonorBloodGroup.setText("Blood Group: "+String.valueOf(docSnapshot1.getString("bloodGroup")));
                                holder.tvDonationStatus.setText("Status: "+String.valueOf(bloodDonation.getDonationStatus()));
                                holder.tvBloodBank.setText("Blood Bank: "+String.valueOf(docSnapshot2.getString("bloodBankName")));
                                holder.tvDonationDate.setText("Date: "+String.valueOf(bloodDonation.getDonationDate()));
                                if(String.valueOf(bloodDonation.getDonationType()).equals("BloodDrive"))
                                {
                                    fStore.collection("BloodDrive").document(String.valueOf(bloodDonation.getBloodDriveID())).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task3) {
                                            if(task3.isSuccessful())
                                            {
                                                DocumentSnapshot docSnapshot3=task3.getResult();
                                                holder.tvBloodDrive.setText("Blood Drive: "+String.valueOf(docSnapshot3.getString("driveName")));
                                                holder.tvDonationAddress.setText("Venue: "+String.valueOf(docSnapshot3.getString("driveVenue")));
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    holder.tvBloodDrive.setVisibility(View.GONE);
                                    holder.tvDonationAddress.setText("Address: "+String.valueOf(docSnapshot2.getString("bloodBankAddress")));
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    @NonNull
    @Override
    public DisplayDonationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_user_display_donation,parent,false);
        return new DisplayDonationRecyclerAdapter.DisplayDonationViewHolder(view);
    }

    public static class DisplayDonationViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvDonorName,tvDonorBloodGroup,tvDonationDate,tvBloodDrive,tvBloodBank,tvDonationAddress,tvDonationStatus;
        CardView ApproveDonationLinLayout;
        public DisplayDonationViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvDonorName =(TextView)itemView.findViewById(R.id.tv_donor_name3);
            tvDonorBloodGroup =(TextView)itemView.findViewById(R.id.tv_donor_blood_group3);
            tvDonationDate =(TextView)itemView.findViewById(R.id.tv_donation_date2);
            tvBloodDrive =(TextView)itemView.findViewById(R.id.tv_donation_blood_drive2);
            tvBloodBank =(TextView)itemView.findViewById(R.id.tv_donation_blood_bank2);
            tvDonationAddress =(TextView)itemView.findViewById(R.id.tv_donation_address2);
            tvDonationStatus=(TextView)itemView.findViewById(R.id.tv_donation_status);
            ApproveDonationLinLayout =(CardView)itemView.findViewById(R.id.cardViewDisplayDonation);
        }
    }
}
