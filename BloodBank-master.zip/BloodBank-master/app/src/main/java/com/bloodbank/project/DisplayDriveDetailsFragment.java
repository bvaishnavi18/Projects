package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import es.dmoral.toasty.Toasty;

public class DisplayDriveDetailsFragment extends Fragment {
   private static final String TAG= DisplayDriveDetailsFragment.class.getSimpleName();
   TextView txtName,txtBloodGroup,txtDriveName,txtDriveContactNo,txtDriveVenue,txtDate,txtDriveStartTime,txtDriveEndTime,txtDriveBloodBank;
   Button btnRegisterBloodDrive;
   String bloodDriveID,bloodBankID;
   Long timeStamp;
   FirebaseAuth fAuth=FirebaseAuth.getInstance();
   FirebaseFirestore fStore=FirebaseFirestore.getInstance();

    @Override
    public void onStart() {
        super.onStart();
        fStore.collection("User").document(fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                if(task1.isSuccessful())
                {
                    DocumentSnapshot docSnapshot1=task1.getResult();
                    txtName.setText("Name: "+String.valueOf(docSnapshot1.getString("userName")));
                    txtBloodGroup.setText("Blood Group: "+String.valueOf(docSnapshot1.getString("bloodGroup")));
                    fStore.collection("BloodDrive").document(bloodDriveID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task2) {
                            if(task2.isSuccessful())
                            {
                                DocumentSnapshot docSnapshot2=task2.getResult();
                                txtDriveName.setText("Drive Name: "+String.valueOf(docSnapshot2.getString("driveName")));
                                txtDriveContactNo.setText("Contact No: "+String.valueOf(docSnapshot2.getString("driveContactNo")));
                                txtDriveVenue.setText("Venue: "+String.valueOf(docSnapshot2.getString("driveVenue")));
                                txtDate.setText("Date: "+String.valueOf(docSnapshot2.getString("driveDate")));
                                txtDriveStartTime.setText("Start Time: "+String.valueOf(docSnapshot2.getString("driveStartTime")));
                                txtDriveEndTime.setText("End Time: "+String.valueOf(docSnapshot2.getString("driveEndTime")));
                                fStore.collection("BloodBank").document(String.valueOf(bloodBankID)).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task3) {
                                        if(task3.isSuccessful())
                                        {
                                            DocumentSnapshot docSnapshot3=task3.getResult();
                                            txtDriveBloodBank.setText("Conducted By: "+String.valueOf(docSnapshot3.getString("bloodBankName")));
                                        }
                                    }
                                });

                            }
                        }
                    });
                }
            }
        });

    }

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState){
       ViewGroup root=(ViewGroup) inflater.inflate(R.layout.fragment_drive_user_details,null);
        Bundle result=getArguments();
        bloodDriveID=result.getString("bloodDriveID");
        bloodBankID=result.getString("bloodBankID");
        txtName=root.findViewById(R.id.tv_user_drive_name);
        txtBloodGroup=root.findViewById(R.id.tv_user_drive_blood_group);
        txtDriveName=root.findViewById(R.id.tv_blood_drive_name);
        txtDriveContactNo=root.findViewById(R.id.tv_blood_drive_contact);
        txtDriveVenue=root.findViewById(R.id.tv_drive_venue);
        txtDate=root.findViewById(R.id.tv_drive_date);
        txtDriveStartTime=root.findViewById(R.id.tv_drive_start_time);
        txtDriveEndTime=root.findViewById(R.id.tv_drive_end_time);
        txtDriveBloodBank=root.findViewById(R.id.tv_drive_blood_bank);
        btnRegisterBloodDrive=root.findViewById(R.id.btnRegisterBloodDrive);

        btnRegisterBloodDrive.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                fStore.collection("User").document(fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task1) {
                        if(task1.isSuccessful())
                        {
                            DocumentSnapshot docSnapshot1=task1.getResult();
                            BloodDonation bloodDonation=new BloodDonation();
                            bloodDonation.setUserID(String.valueOf(fAuth.getCurrentUser().getUid()));
                            bloodDonation.setBloodGroup(String.valueOf(docSnapshot1.getString("bloodGroup")));
                            bloodDonation.setDonationDate(String.valueOf(txtDate.getText().toString().replace("Date: ","")));
                            bloodDonation.setDonationTimeStamp(null);
                            bloodDonation.setDonationType(String.valueOf("BloodDrive"));
                            bloodDonation.setBloodDriveID(String.valueOf(bloodDriveID));
                            bloodDonation.setBloodBankID(String.valueOf(bloodBankID));
                            bloodDonation.setDonationStatus("Pending");
                            fStore.collection("BloodDonation").add(bloodDonation).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentReference> task2) {
                                    if(task2.isSuccessful())
                                    {
                                        Toasty.success(getContext(), "Registered to Blood Drive Sucessfully!!", Toast.LENGTH_SHORT).show();
                                        Log.i(TAG,"Registered to Blood Drive Sucessfully!!");
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toasty.error(getContext(), "Failed to Register to Blood Drive!!", Toast.LENGTH_SHORT).show();
                                    Log.e(TAG,e.getMessage());
                                }
                            });
                        }
                    }
                });
            }
        });

       return root;
   }
}