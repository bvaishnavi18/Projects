package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class DonationHistoryFragment extends Fragment {
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    FirebaseAuth fAuth = FirebaseAuth.getInstance();
    TextView tvBloodBankHeading,tvBloodDriveHeading;
    private Query query1,query2;
    private int count1=0,count2=0;
    RecyclerView displayBloodBankRecyclerView,displayBloodDriveRecyclerView;
    DisplayDonationRecyclerAdapter adapter1;

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_donation_history, null);
        displayBloodBankRecyclerView=(RecyclerView)root.findViewById(R.id.cardview_bloodbank_recyclerview2);
        displayBloodDriveRecyclerView=(RecyclerView)root.findViewById(R.id.cardview_blooddrive_recyclerview2);
        tvBloodBankHeading=(TextView)root.findViewById(R.id.tv_bloodbank_cardview_heading2);
        tvBloodDriveHeading=(TextView)root.findViewById(R.id.tv_blooddrive_cardview_heading2);

        tvBloodBankHeading.setVisibility(View.GONE);
        displayBloodBankRecyclerView.setVisibility(View.GONE);
        tvBloodDriveHeading.setVisibility(View.GONE);
        displayBloodDriveRecyclerView.setVisibility(View.GONE);

        fStore.collection("BloodDonation").whereEqualTo("donationType","BloodBank").whereEqualTo("userID",fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task1) {
                if (task1.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task1.getResult()) {
                        count1++;
                    }
                    if(count1!=0)
                    {
                        tvBloodBankHeading.setVisibility(View.VISIBLE);
                        displayBloodBankRecyclerView.setVisibility(View.VISIBLE);
                        query1 = fStore.collection("BloodDonation").whereEqualTo("donationType","BloodBank").whereEqualTo("userID",fAuth.getCurrentUser().getUid());
                        FirestoreRecyclerOptions<BloodDonation> bloodDonationOpt = new FirestoreRecyclerOptions.Builder<BloodDonation>().setQuery(query1, BloodDonation.class).build();
                        adapter1=new DisplayDonationRecyclerAdapter(bloodDonationOpt,getContext());
                        displayBloodBankRecyclerView.setAdapter(adapter1);
                        displayBloodBankRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter1.startListening();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Records Found!!");
                        displayBloodBankRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayBloodBankRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });

        fStore.collection("BloodDonation").whereEqualTo("donationType","BloodDrive").whereEqualTo("userID",fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task2) {
                if (task2.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task2.getResult()) {
                        count2++;
                    }
                    if(count2!=0)
                    {
                        tvBloodDriveHeading.setVisibility(View.VISIBLE);
                        displayBloodDriveRecyclerView.setVisibility(View.VISIBLE);
                        query2 = fStore.collection("BloodDonation").whereEqualTo("donationType","BloodDrive").whereEqualTo("userID",fAuth.getCurrentUser().getUid());
                        FirestoreRecyclerOptions<BloodDonation> bloodDonationOpt = new FirestoreRecyclerOptions.Builder<BloodDonation>().setQuery(query2, BloodDonation.class).build();
                        adapter1=new DisplayDonationRecyclerAdapter(bloodDonationOpt,getContext());
                        displayBloodDriveRecyclerView.setAdapter(adapter1);
                        displayBloodDriveRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter1.startListening();

                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Records Found!!");
                        displayBloodDriveRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        displayBloodDriveRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });
        return root;
    }
}