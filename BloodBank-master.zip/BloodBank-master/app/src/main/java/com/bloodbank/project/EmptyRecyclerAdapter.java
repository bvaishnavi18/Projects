package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EmptyRecyclerAdapter<M extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<EmptyRecyclerAdapter.EmptyViewHolder>{
    public Context hContext;
    public String emptyMessage;

    public EmptyRecyclerAdapter(Context hContext, String emptyMessage) {
        this.hContext = hContext;
        this.emptyMessage=emptyMessage;
    }
    @NonNull
    @Override
    public EmptyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.empty_view,parent,false);
        return new EmptyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmptyRecyclerAdapter.EmptyViewHolder holder, final int position) {
        holder.tvEmpty.setText(emptyMessage);
    }

    public int getItemCount() {
        return 1;
    }

    public static class EmptyViewHolder extends RecyclerView.ViewHolder{
        TextView tvEmpty;
        LinearLayout emptyLinear;
        public EmptyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmpty=(TextView)itemView.findViewById(R.id.tvEmptyMsg);
            emptyLinear=(LinearLayout)itemView.findViewById(R.id.empty_linearView);
        }
    }
}
