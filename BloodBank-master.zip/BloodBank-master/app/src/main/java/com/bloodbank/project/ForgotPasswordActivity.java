package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {
    EditText etEmailID;
    Button btnForgotPass;
    private final FirebaseAuth fAuth=FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        etEmailID=findViewById(R.id.etForgEmail);
        btnForgotPass=findViewById(R.id.btnForgotPass);

        btnForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    fAuth.sendPasswordResetEmail(etEmailID.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(ForgotPasswordActivity.this, "Check email to reset your password!", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(ForgotPasswordActivity.this, "Fail to send reset password email!", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    });
                }
            }
        });

    }
    public Boolean ValidateData()
    {
        boolean isDataValid=true;
        if(etEmailID.getText().toString().equals(""))
        {
            isDataValid=false;
            etEmailID.setError("Please Enter Email");
            etEmailID.requestFocus();
        }
        if(!etEmailID.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"))
        {
            isDataValid=false;
            etEmailID.setError("Invalid Email");
            etEmailID.requestFocus();
        }
        return isDataValid;
    }
}