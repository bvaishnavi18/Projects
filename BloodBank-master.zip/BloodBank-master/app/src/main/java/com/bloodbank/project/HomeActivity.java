package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

import es.dmoral.toasty.Toasty;

import static com.bloodbank.project.R.id.drawer_email;
import static com.bloodbank.project.R.id.drawer_name;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private final FirebaseAuth fAuth = FirebaseAuth.getInstance();
    private final FirebaseFirestore fStore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        final NavigationView navigationView = findViewById(R.id.nav_user_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(HomeActivity.this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container, new UserHomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_user_home);
        }
        FirebaseUser user = fAuth.getCurrentUser();
        String userId = user.getUid();
        fStore.collection("User").document(userId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot docSnapshot = task.getResult();
                    String EmailID = docSnapshot.getString("userEmail");
                    String Name = docSnapshot.getString("userName");
                    //Toast.makeText(HomeActivity.this,EmailID,Toast.LENGTH_SHORT).show();
                    View headerView = navigationView.getHeaderView(0);
                    TextView txtEmail = (TextView) headerView.findViewById(drawer_email);
                    txtEmail.setText(EmailID);
                    TextView txtDrawerName = (TextView) headerView.findViewById(drawer_name);
                    txtDrawerName.setText(Name);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            //super.onBackPressed();
            if (getFragmentManager().getBackStackEntryCount() <= 1) {
                super.onBackPressed();
            } else {
                getFragmentManager().popBackStack();
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId())
        {
            case R.id.nav_user_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new UserHomeFragment()).commit();
                break;
            case R.id.nav_user_blood_request:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new RequestBloodFragment()).commit();
                break;
            case R.id.nav_user_donate_blood:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new BloodDonateFragment()).commit();
                break;
            case R.id.nav_user_transcations:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new DonationHistoryFragment()).commit();
                break;
            case R.id.nav_user_profile:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new MyAccountFragment()).commit();
                break;
            case R.id.nav_contact:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_user_container,new ContactUsFragment()).commit();
                break;
            case R.id.nav_user_sign_out:
                FirebaseAuth.getInstance().signOut();
                Intent signoutintent = new Intent(HomeActivity.this,LoginActivity.class);
                startActivity(signoutintent);
                finish();
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}