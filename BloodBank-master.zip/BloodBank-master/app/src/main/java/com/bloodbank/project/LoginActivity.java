package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.RemoteMessage;


import es.dmoral.toasty.Toasty;

public class LoginActivity extends AppCompatActivity {
    TextView tvRegister,tvForgotPass;
    EditText etEmailID,etPassword;
    Button btnLogin,btnMap;
    private static final String TAG= HomeActivity.class.getSimpleName();
    private final FirebaseAuth fAuth=FirebaseAuth.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tvRegister =findViewById(R.id.txtSignUp);
        tvForgotPass=findViewById(R.id.txtForget);
        etEmailID=findViewById(R.id.txtLogEmail);
        etPassword=findViewById(R.id.txtLogPass);
        btnLogin= findViewById(R.id.btnLogin);
        //btnMap=findViewById(R.id.btnMap);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if(task.isSuccessful())
                {
                    String token=task.getResult();
                   // sendToToken(token);
                    Log.i(TAG,"Token ID: "+token);

                }

            }


        });



        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {

                    if (etEmailID.getText().toString().equals("administrator@gmail.com")) {
                        fAuth.signInWithEmailAndPassword(etEmailID.getText().toString(),etPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {
                                    Intent loginIntent = new Intent(LoginActivity.this, AdminHomeActivity.class);
                                    Toasty.success(LoginActivity.this, "Login Successful!!!", Toast.LENGTH_SHORT).show();
                                    loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(loginIntent);
                                    finish();
                                }
                                else{
                                    Toasty.error(LoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                    else  {
                        fAuth.signInWithEmailAndPassword(etEmailID.getText().toString(), etPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent loginIntent = new Intent(LoginActivity.this, HomeActivity.class);
                                    Toasty.success(LoginActivity.this,"Login Successful !!",Toast.LENGTH_SHORT).show();
                                    startActivity(loginIntent);
                                    finish();
                                }
                                else
                                {
                                    Toasty.error(LoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
                else
                {
                    Toasty.error(LoginActivity.this, "Invalid Data!!!", Toast.LENGTH_SHORT).show();
                }
//
            }

        });
//        btnMap.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(LoginActivity.this,MapActivity.class);
//                startActivity(intent);
//            }
//        });

        tvForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent regIntent=new Intent(LoginActivity.this,ForgotPasswordActivity.class);
                startActivity(regIntent);
            }
        });

        tvRegister.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent regIntent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(regIntent);
                finish();
            }
        });
    }

    public Boolean ValidateData()
    {
        boolean isDataValid=true;
        if(etEmailID.getText().toString().equals("")||etPassword.getText().toString().equals(""))
        {
            isDataValid=false;
        }
        return isDataValid;
    }
    private static final String  CHANNNEL_ID="bloodBank";
    private static final  String CHANNEL_DESC="bloodBankNotifications";
    private  static  final  String CHANNEL_NAME="bloodBankName";

    private void displayNotification()
    {
        NotificationCompat.Builder builder=new NotificationCompat.Builder(LoginActivity.this,CHANNNEL_ID)
                .setSmallIcon(R.drawable.common_google_signin_btn_icon_dark)
                .setContentTitle("BloodBank App")
                .setContentText("Welcome to the Blood Bank App")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                ;
                NotificationManagerCompat managerCompat=NotificationManagerCompat.from(LoginActivity.this);
                managerCompat.notify(1,builder.build());
    }

}