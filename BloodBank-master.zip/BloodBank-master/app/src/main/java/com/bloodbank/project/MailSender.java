package com.bloodbank.project;

import android.os.StrictMode;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailSender {
    final String mailID="bloodbankapp39@gmail.com";
    final String password="bloodBank123";
    String upperMessage;
    final String lowerMessage= "\n\n\n\n\n\n\n\n\nRegards,\nBloodBank App";;

    public String getUpperMessage() {
        return upperMessage;
    }

    public Session mailConfig()
    {
        Properties properties=new Properties();
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host","smtp.gmail.com");
        properties.put("mail.smtp.port","587");
        Session session=Session.getInstance(properties,new javax.mail.Authenticator(){
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(mailID,password);
            }
        });
        return session;
    }

    public void sendMail(String subject,String middleMessage,String userID){
        FirebaseFirestore.getInstance().collection("User").document(userID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful())
                {
                    DocumentSnapshot docSnapshot=task.getResult();
                    String toEmail=String.valueOf(docSnapshot.getString("userEmail"));
                    upperMessage ="Hi "+String.valueOf(docSnapshot.getString("userName"))+"\n\n\n";
                    String bodyMessage=upperMessage+middleMessage+lowerMessage;
                    try
                    {
                        javax.mail.Message message=new MimeMessage(mailConfig());
                        message.setFrom(new InternetAddress(toEmail));
                        message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(toEmail));
                        message.setSubject(subject);
                        message.setText(bodyMessage);
                        Transport.send(message);
                    }
                    catch (MessagingException e)
                    {
                        new RuntimeException(e);
                    }
                }
            }
        });

    }


}