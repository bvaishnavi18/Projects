package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class MyAccountFragment extends Fragment {
    private static final String TAG=MyAccountFragment.class.getSimpleName();
    EditText etName,etPhone;
    Spinner spBloodGroup,spCity;
    CheckBox cbDonor;
    TextView etDateOfBirth;
    RadioGroup rgGender;
    RadioButton rbGender,rbMale,rbFemale;
    Button btnUpdateProfile;
    private DatePickerDialog.OnDateSetListener sDateSetListener;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    FirebaseAuth fAuth = FirebaseAuth.getInstance();
    List<String> lstBloodGroup=new ArrayList<String>();
    List<String> lstCity=new ArrayList<String>();
    int year,month,day;

    @Override
    public void onStart() {
        super.onStart();
        fStore.collection("User").document(fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful())
                {
                    DocumentSnapshot docSnapshot=task.getResult();
                    etName.setText(String.valueOf(docSnapshot.getString("userName")));
                    etPhone.setText(String.valueOf(docSnapshot.getLong("phoneNumber")));
                    etDateOfBirth.setText(String.valueOf(docSnapshot.getString("dateOfBirth")));
                    if(String.valueOf(docSnapshot.getString("gender")).equals("Male"))
                    {
                        rbMale.setChecked(true);
                    }
                    else
                    {
                        rbFemale.setChecked(true);
                    }
                    if(docSnapshot.getBoolean("donor").equals(true))
                    {
                        cbDonor.setChecked(true);
                    }
                    else
                    {
                        cbDonor.setChecked(false);
                    }
                    spBloodGroup.setSelection(lstBloodGroup.indexOf(docSnapshot.getString("bloodGroup")));
                    spCity.setSelection(lstCity.indexOf(docSnapshot.getString("userCity")));
                }
            }
        });

    }

    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        ViewGroup root= (ViewGroup) inflater.inflate(R.layout.fragment_myaccount,null);
        etName=root.findViewById(R.id.txtName2);
        etPhone=root.findViewById(R.id.txtPhone2);
        spBloodGroup=root.findViewById(R.id.spBloodGroup2);
        spCity=root.findViewById(R.id.spCity2);
        etDateOfBirth=root.findViewById(R.id.etDateOfBirth2);
        rgGender=root.findViewById(R.id.rgGender2);
        rbMale=root.findViewById(R.id.rbMale2);
        rbFemale=root.findViewById(R.id.rbFemale2);
        cbDonor=root.findViewById(R.id.cbDonor2);
        btnUpdateProfile=root.findViewById(R.id.btnUpdateProfile);

        String[] bloodValues = new String[] {"Select Blood Group", "A+" , "A-" , "B+" , "B-" , "AB+" , "AB-" ,"O+" , "O-" };
        for (int i = 0; i < bloodValues.length; ++i) {
            lstBloodGroup.add(bloodValues[i]);
        }
        final ArrayAdapter<String> adapter=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstBloodGroup);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBloodGroup.setAdapter(adapter);

        String[] cityValue= new String[]{"Select Your City", "Kalyan", "Dombivli", "Thakurli", "Ulhasnagar", "Thane","Mulund","Ghatkopar","Kurla","Dadar"};
        for (int i = 0; i < cityValue.length; ++i) {
            lstCity.add(cityValue[i]);
        }
        final ArrayAdapter<String> adapter2=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstCity);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCity.setAdapter(adapter2);

        etDateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                year = cal.get(Calendar.YEAR);
                month = cal.get(Calendar.MONTH);
                day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(getContext(),sDateSetListener,year,month,day);
                dialog.show();
            }
        });

        sDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                etDateOfBirth.setText(String.format("%02d/%02d/%02d",day,month,year));
            }
        };

        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    rbGender=root.findViewById(rgGender.getCheckedRadioButtonId());
                    DocumentReference docReference=fStore.collection("User").document(fAuth.getCurrentUser().getUid());
                    docReference.update("userName",String.valueOf(etName.getText().toString()));
                    docReference.update("phoneNumber",Long.valueOf(etPhone.getText().toString()));
                    docReference.update("dateOfBirth",String.valueOf(etDateOfBirth.getText().toString()));
                    docReference.update("gender",String.valueOf(rbGender.getText().toString()));
                    docReference.update("userCity",String.valueOf(spCity.getSelectedItem().toString()));
                    docReference.update("donor",cbDonor.isChecked());
                    docReference.update("bloodGroup",String.valueOf(spBloodGroup.getSelectedItem().toString())).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.i(TAG,"User Profile Changed Sucessfully!!");
                            Toasty.success(getContext(), "User Profile Updated Sucessfully!!", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG,e.getMessage());
                            Toasty.error(getContext(), "Failed to Update User Profile!!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toasty.error(getContext(), "Invalid Data!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return root;
    }
    public boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etName.getText().toString().equals("")||etPhone.getText().toString().equals("")||etDateOfBirth.getText().toString().equals("__________________"))
        {
            isDataValid=false;
        }
        if(spBloodGroup.getSelectedItem().toString().equals("Select Blood Group"))
        {
            isDataValid=false;
            Toasty.error(getContext(), "Please Select Blood Group", Toast.LENGTH_SHORT).show();
        }
        if(spCity.getSelectedItem().toString().equals("Select Your City"))
        {
            isDataValid=false;
            Toasty.error(getContext(), "Please Select City", Toast.LENGTH_SHORT).show();
        }
        if(!(etPhone.getText().toString().matches("[0-9]{10}"))){
            isDataValid=false;
            Toasty.error(getContext(), "Invalid Phone Number", Toast.LENGTH_SHORT).show();
            etPhone.requestFocus();
        }
        return isDataValid;
    }
}