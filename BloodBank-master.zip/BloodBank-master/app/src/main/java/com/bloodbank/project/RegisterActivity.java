package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class RegisterActivity extends AppCompatActivity {
    private static final String TAG=RegisterActivity.class.getSimpleName();
    EditText etName,etPhone,etEmail,etPass,etConPass;
    CheckBox cbDonor;
    Button btnRegister;
    TextView tvLogin,etDateOfBirth;
    Spinner spBloodGroup,spCity;
    RadioGroup rgGender;
    RadioButton rbGender;
    private DatePickerDialog.OnDateSetListener sDateSetListener;
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    FirebaseAuth fAuth = FirebaseAuth.getInstance();
    List<String> lstBloodGroup=new ArrayList<String>();
    List<String> lstCity=new ArrayList<String>();
    int year,month,day;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        tvLogin=findViewById(R.id.txtLoginBtn);
        etName=findViewById(R.id.txtName);
        etEmail=findViewById(R.id.txtEmail);
        etPhone=findViewById(R.id.txtPhone);
        etPass=findViewById(R.id.txtPass);
        etConPass=findViewById(R.id.txtConPass);
        etDateOfBirth=findViewById(R.id.etDateOfBirth);
        cbDonor=findViewById(R.id.cbDonor);
        spBloodGroup= findViewById(R.id.spBloodGroup);
        spCity=findViewById(R.id.spCity);
        rgGender=findViewById(R.id.rgGender);
        btnRegister= findViewById(R.id.btnReg);

        String[] bloodvalues = new String[] {"Select Blood Group", "A+" , "A-" , "B+" , "B-" , "AB+" , "AB-" ,"O+" , "O-" };
        for (int i = 0; i < bloodvalues.length; ++i) {
            lstBloodGroup.add(bloodvalues[i]);
        }
        final ArrayAdapter<String> adapter=new ArrayAdapter<String>(RegisterActivity.this,android.R.layout.simple_spinner_item, lstBloodGroup);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBloodGroup.setAdapter(adapter);

        String[] cityValue= new String[]{"Select Your City", "Kalyan", "Dombivli", "Thakurli", "Ulhasnagar", "Thane","Mulund","Ghatkopar","Kurla","Dadar"};
        for (int i = 0; i < cityValue.length; ++i) {
            lstCity.add(cityValue[i]);
        }
        final ArrayAdapter<String> adapter2=new ArrayAdapter<String>(RegisterActivity.this,android.R.layout.simple_spinner_item, lstCity);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCity.setAdapter(adapter2);

        etDateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                year = cal.get(Calendar.YEAR);
                month = cal.get(Calendar.MONTH);
                day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(RegisterActivity.this,sDateSetListener,year,month,day);
                dialog.show();
            }
        });
        sDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                etDateOfBirth.setText(String.format("%02d/%02d/%02d",day,month,year));
            }
        };
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidateData())
                {
                    fAuth.createUserWithEmailAndPassword(etEmail.getText().toString(),etPass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful())
                            {
                                FirebaseUser fUser=fAuth.getCurrentUser();
                                String userID=fUser.getUid();
                                rbGender=findViewById(rgGender.getCheckedRadioButtonId());
                                DocumentReference documentReference=fStore.collection("User").document(userID);
                                User user =new User();
                                user.setUserName(etName.getText().toString());
                                user.setUserEmail(etEmail.getText().toString());
                                user.setPhoneNumber(Long.valueOf(etPhone.getText().toString()));
                                user.setDonor(cbDonor.isChecked());
                                user.setBloodGroup(spBloodGroup.getSelectedItem().toString());
                                user.setDateOfBirth(etDateOfBirth.getText().toString());
                                user.setUserCity(spCity.getSelectedItem().toString());
                                user.setGender(rbGender.getText().toString());
                                user.setVerifyDonor(false);
                                //Toast.makeText(RegisterActivity.this, String.valueOf(cbDonor.isChecked()), Toast.LENGTH_SHORT).show();
                                documentReference.set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful())
                                        {
                                            Log.i(TAG,"Registration Done");
                                            Toasty.success(RegisterActivity.this, "User Registered Successfully!!", Toast.LENGTH_SHORT).show();
                                            Intent regintent = new Intent(RegisterActivity.this,HomeActivity.class);
                                            startActivity(regintent);
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG,e.getMessage());
                                        Toasty.error(RegisterActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                                if(task.getException() instanceof FirebaseAuthUserCollisionException)
                                {
                                    Toasty.info(RegisterActivity.this,"You are Already Registered",Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });

                }
                else
                {
                    Toasty.error(RegisterActivity.this, "Invalid Data!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        tvLogin.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent regIntent=new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(regIntent);
                finish();
            }
        });
    }
    public boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etName.getText().toString().equals("")||etEmail.getText().toString().equals("")||etPass.getText().toString().equals("")||etConPass.getText().toString().equals("")||etDateOfBirth.getText().toString().equals("")||etDateOfBirth.getText().toString().equals("__________________"))
        {
            isDataValid=false;
        }
        if(spBloodGroup.getSelectedItem().toString().equals("Select Blood Group"))
        {
            isDataValid=false;
            Toasty.error(RegisterActivity.this, "Please Select Blood Group", Toast.LENGTH_SHORT).show();
        }
        if(spCity.getSelectedItem().toString().equals("Select Your City"))
        {
            isDataValid=false;
            Toasty.error(RegisterActivity.this, "Please Select City", Toast.LENGTH_SHORT).show();
        }
        if(!(etPhone.getText().toString().matches("[0-9]{10}"))){
            isDataValid=false;
            etPhone.setError("Invalid Phone Number");
            etPhone.requestFocus();
        }
        if(!(etPass.getText().toString().equals(etConPass.getText().toString())))
        {
            isDataValid=false;
            etPass.setError("Incorrect Password");
            etPass.requestFocus();
        }
        return isDataValid;
    }
}