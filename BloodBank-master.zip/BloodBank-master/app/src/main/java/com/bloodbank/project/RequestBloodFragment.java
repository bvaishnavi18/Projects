package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class RequestBloodFragment extends Fragment {
    private static final String TAG=RequestBloodFragment.class.getSimpleName();
    FirebaseFirestore fStore=FirebaseFirestore.getInstance();
    FirebaseAuth fAuth = FirebaseAuth.getInstance();
    FloatingActionButton fabtnRequestBlood;
    EditText etName,etPhone;
    Spinner spCity,spBloodGroup;
    Button btnDialogRequestBlood;
    String strCurDate;
    RequestBloodRecyclerAdapter adapter;
    RecyclerView requestBloodRecyclerView;
    private Dialog dialog;
    private List<String> lstCity,lstBloodGroup;
    int count = 0;
    Query query;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_request_blood, null);
        fabtnRequestBlood=root.findViewById(R.id.fabtnSearchRequest);
        requestBloodRecyclerView=root.findViewById(R.id.Request_Blood_RecyclerView);

        fStore.collection("BloodRequest").whereEqualTo("userID",fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        count++;
                    }
                    if(count!=0)
                    {
                        query = fStore.collection("BloodRequest").whereEqualTo("userID",fAuth.getCurrentUser().getUid());
                        FirestoreRecyclerOptions<BloodRequest> custOpt = new FirestoreRecyclerOptions.Builder<BloodRequest>().setQuery(query, BloodRequest.class).build();
                        adapter=new RequestBloodRecyclerAdapter(custOpt,getContext());
                        requestBloodRecyclerView.setAdapter(adapter);
                        requestBloodRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        adapter.startListening();
                        adapter.notifyDataSetChanged();
                    }
                    else
                    {
                        EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder> emptyAdapter = new EmptyRecyclerAdapter<EmptyRecyclerAdapter.EmptyViewHolder>(getContext(), "No Blood Requests Found!!");
                        requestBloodRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        requestBloodRecyclerView.setAdapter(emptyAdapter);
                    }
                }
            }
        });

        fabtnRequestBlood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog=new Dialog(getContext());
                dialog.setContentView(R.layout.dialogbox_request_blood);
                dialog.setCanceledOnTouchOutside(true);
                etName=(EditText)dialog.findViewById(R.id.txtName3);
                etPhone=(EditText)dialog.findViewById(R.id.txtPhone3);
                spCity=(Spinner)dialog.findViewById(R.id.spCity3);
                spBloodGroup=(Spinner)dialog.findViewById(R.id.spBloodGroup3);
                btnDialogRequestBlood=(Button)dialog.findViewById(R.id.btnRequestBlood);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialog.getWindow().getAttributes());
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                lp.gravity = Gravity.CENTER;
                //lp.horizontalMargin=15f;
                dialog.getWindow().setAttributes(lp);
                lstCity=new ArrayList<>();
                lstBloodGroup=new ArrayList<>();

                String[] bloodvalues = new String[] {"Select Blood Group", "A+" , "A-" , "B+" , "B-" , "AB+" , "AB-" ,"O+" , "O-" };
                for (int i = 0; i < bloodvalues.length; ++i) {
                    lstBloodGroup.add(bloodvalues[i]);
                }
                final ArrayAdapter<String> adapter=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstBloodGroup);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spBloodGroup.setAdapter(adapter);

                String[] cityValue= new String[]{"Select Your City", "Kalyan", "Dombivli", "Thakurli", "Ulhasnagar", "Thane","Mulund","Ghatkopar","Kurla","Dadar"};
                for (int i = 0; i < cityValue.length; ++i) {
                    lstCity.add(cityValue[i]);
                }
                final ArrayAdapter<String> adapter2=new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_item, lstCity);
                adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spCity.setAdapter(adapter2);

                fStore.collection("User").document(fAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if(task.isSuccessful())
                        {
                            DocumentSnapshot docSnapshot=task.getResult();
                            etName.setText(String.valueOf(docSnapshot.getString("userName")));
                            etPhone.setText(String.valueOf(docSnapshot.getLong("phoneNumber")));
                            spBloodGroup.setSelection(lstBloodGroup.indexOf(docSnapshot.getString("bloodGroup")));
                            spCity.setSelection(lstCity.indexOf(docSnapshot.getString("userCity")));
                        }
                    }
                });

                btnDialogRequestBlood.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(View view) {
                        if(ValidateData())
                        {
                            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                            LocalDateTime localDateTime = LocalDateTime.now();
                            String strCurTime = localDateTime.format(dateTimeFormatter);
                            strCurDate=localDateTime.format(dateFormat);
                            Timestamp curTimeStamp = Timestamp.valueOf(strCurTime);
                            final Long curStampVal = curTimeStamp.getTime();

                            BloodRequest bloodRequest=new BloodRequest();
                            bloodRequest.setRecipientName(String.valueOf(etName.getText().toString()));
                            bloodRequest.setRecipientPhone(Long.valueOf(etPhone.getText().toString()));
                            bloodRequest.setRecipientCity(String.valueOf(spCity.getSelectedItem().toString()));
                            bloodRequest.setRecipientBloodGroup(String.valueOf(spBloodGroup.getSelectedItem().toString()));
                            bloodRequest.setRequestDate(String.valueOf(strCurDate));
                            bloodRequest.setRequestTimeStamp(Long.valueOf(curStampVal));
                            bloodRequest.setUserID(String.valueOf(fAuth.getCurrentUser().getUid()));
                            bloodRequest.setBloodBankID(null);
                            bloodRequest.setStatus("Pending");
                            fStore.collection("BloodRequest").add(bloodRequest).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentReference> task) {
                                    if(task.isSuccessful())
                                    {
                                        Toasty.success(getContext(), "Blood Request Created Successfully!!", Toast.LENGTH_SHORT).show();
                                        Log.i(TAG,"Blood Request Created Successfully!!");
                                        dialog.dismiss();
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toasty.error(getContext(), "Failed to add Blood Request!!", Toast.LENGTH_SHORT).show();
                                    Log.e(TAG,"Error: "+e.getMessage());
                                    dialog.dismiss();
                                }
                            });
                        }
                        else
                        {
                            Toasty.error(getContext(), "Invalid Data!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                dialog.show();
            }
        });

        return root;
    }
    public boolean ValidateData()
    {
        Boolean isDataValid=true;
        if(etName.getText().toString().equals("")||etPhone.getText().toString().equals(""))
        {
            isDataValid=false;
        }
        if(spBloodGroup.getSelectedItem().toString().equals("Select Blood Group"))
        {
            isDataValid=false;
            Toasty.error(getContext(), "Please Select Blood Group", Toast.LENGTH_SHORT).show();
        }
        if(spCity.getSelectedItem().toString().equals("Select Your City"))
        {
            isDataValid=false;
            Toasty.error(getContext(), "Please Select City", Toast.LENGTH_SHORT).show();
        }
        if(!(etPhone.getText().toString().matches("[0-9]{10}"))){
            isDataValid=false;
            etPhone.setError("Invalid Phone Number");
            etPhone.requestFocus();
        }
        return isDataValid;
    }
}