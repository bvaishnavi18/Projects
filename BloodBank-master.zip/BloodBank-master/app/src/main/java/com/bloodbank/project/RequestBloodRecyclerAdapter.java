package com.bloodbank.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class RequestBloodRecyclerAdapter extends FirestoreRecyclerAdapter<BloodRequest, RequestBloodRecyclerAdapter.RequestBloodViewHolder> {
   Context context;
   public RequestBloodRecyclerAdapter(@NonNull FirestoreRecyclerOptions<BloodRequest> options, Context context){
        super(options);
        this.context=context;
   }

    @Override
    protected void onBindViewHolder(@NonNull RequestBloodViewHolder holder, int position, @NonNull BloodRequest bloodRequest) {
        holder.tvRecipientName.setText("Name: "+String.valueOf(bloodRequest.getRecipientName()));
        holder.tvRecipientPhone.setText("Contact No: "+String.valueOf(Long.valueOf(bloodRequest.getRecipientPhone())));
        holder.tvRecipientBloodGroup.setText("Blood Group: "+String.valueOf(bloodRequest.getRecipientBloodGroup()));
        holder.tvRecipientCity.setText("City: "+String.valueOf(bloodRequest.getRecipientCity()));
        holder.tvRequestDate.setText("Date: "+String.valueOf(bloodRequest.getRequestDate()));
        holder.tvBloodStatus.setText("Status: "+String.valueOf(bloodRequest.getStatus()));
        holder.UserLinLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @NonNull
    @Override
    public RequestBloodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.cardview_user_blood_request,parent,false);
        return new RequestBloodRecyclerAdapter.RequestBloodViewHolder(view);
    }

    public static class RequestBloodViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvRecipientName,tvRecipientPhone,tvRecipientBloodGroup,tvRecipientCity, tvRequestDate,tvBloodStatus;
        CardView UserLinLayout;
        public RequestBloodViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvRecipientName =(TextView)itemView.findViewById(R.id.tvRecipientName);
            tvRecipientPhone=(TextView)itemView.findViewById(R.id.tvRecipientPhone);
            tvRecipientBloodGroup =(TextView)itemView.findViewById(R.id.tvRecipientBloodGroup);
            tvRecipientCity =(TextView)itemView.findViewById(R.id.tvRecipientCity);
            tvRequestDate =(TextView)itemView.findViewById(R.id.tvRequestDate);
            tvBloodStatus=(TextView)itemView.findViewById(R.id.tvBloodStatus);
            UserLinLayout =(CardView)itemView.findViewById(R.id.cardViewUserBloodRequest);
        }
    }
}
