package com.bloodbank.project;

public class User {
    private String userName;
    private String userEmail;
    private String gender;
    private Long phoneNumber;
    private String bloodGroup;
    private Boolean isDonor;
    private String dateOfBirth;
    private String userCity;
    private Boolean verifyDonor;

    public Boolean getVerifyDonor() {
        return verifyDonor;
    }

    public void setVerifyDonor(Boolean verifyDonor) {
        this.verifyDonor = verifyDonor;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getUserCity() {
        return userCity;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public User() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getDonor() {
        return isDonor;
    }

    public void setDonor(Boolean isDonor) {
        this.isDonor = isDonor;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }
}
