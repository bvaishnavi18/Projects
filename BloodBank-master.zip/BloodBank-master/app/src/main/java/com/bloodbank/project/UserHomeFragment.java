package com.bloodbank.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

public class UserHomeFragment extends Fragment {
    CardView beforeDonate,afterDonate,dayofDonation,whoCanDonate,showMessageCard;
    TextView showMessage,headerMessage, headerMessage2, showMessage2;
    CarouselView carouselView;
    public ViewGroup onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragement_user_home, null);
        beforeDonate=root.findViewById(R.id.BeforeDonation);
        afterDonate=root.findViewById(R.id.AfterDonation);
        dayofDonation=root.findViewById(R.id.DayofDonation);
        whoCanDonate=root.findViewById(R.id.whoCanDonate);
        showMessage=root.findViewById(R.id.txtMessage);
        headerMessage=root.findViewById(R.id.txtHeader);
        headerMessage2 =root.findViewById(R.id.txtHeader2);
        showMessage2 =root.findViewById(R.id.txtMessage2);
        showMessageCard=root.findViewById(R.id.showMessageCard);
        carouselView=root.findViewById(R.id.carouselView);
        carouselView.setPageCount(3);
        showMessageCard.setVisibility(View.GONE);
        headerMessage2.setVisibility(View.GONE);
        showMessage2.setVisibility(View.GONE);

        carouselView.setImageListener(new ImageListener() {
            @Override
            public void setImageForPosition(int position, ImageView imageView) {
                switch (position)
                {
                    case 0:
                        imageView.setImageResource(R.drawable.imagee);
                        break;
                    case 1:
                        imageView.setImageResource(R.drawable.download);
                        break;
                    default:
                        imageView.setImageResource(R.drawable.images);
                }

            }
        });

        beforeDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessageCard.setVisibility(View.VISIBLE);
                showMessage2.setVisibility(View.GONE);
                headerMessage2.setVisibility(View.GONE);
                headerMessage.setText("Before Donation: ");
                showMessage.setText(new StringBuilder().append(" Select a donation type and find a convenient time that works best for you.\n").append("\n").append("Get the Dish on Nutrition\n").append("\n").append("Have iron-rich foods, such as red meat, fish, poultry, beans, spinach, iron-fortified cereals or raisins.\n").append("\n").append("Be Well Rested and Hydrate\n").append("\n").append("Get a good night's sleep the night before your donation, eat healthy foods and drink extra liquids.").toString());

            }
        });
        afterDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessageCard.setVisibility(View.VISIBLE);
                showMessage2.setVisibility(View.GONE);
                headerMessage2.setVisibility(View.GONE);
                headerMessage.setText("After Donation: ");
                showMessage.setText(new StringBuilder().append(" Relax for a few minutes in our refreshment and recovery are a have some cookies or other snacks you’ve earned it!\n").append("\n").append("Drink an extra four (8 oz.) glasses of liquids and avoid alcohol over the next 24 hours.\n").append("\n").append("Keep the strip bandage on for the next several hours; to avoid a skin rash, clean the area around the bandage with soap and water.\n").append("Don’t do any heavy lifting or vigorous exercise for the rest of the day.\n").append("If the needle site starts to bleed, apply pressure and raise your arm straight up for 5-10 minutes or until bleeding stops.\n").append("If you experience dizziness or lightheadedness, stop what you’re doing and sit down or lie down until you feel better; avoid performing any activity where fainting may lead to injury for at least 24 hours.\n").append("Keep eating iron-rich foods.").toString());
            }
        });
        whoCanDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessageCard.setVisibility(View.VISIBLE);
                headerMessage.setText("Who Can Donate ");
                showMessage.setText(new StringBuilder().append("You are between age group of 18-65 years.\n").append("Your weight is 45 kgs or more.\n").append("Your haemoglobin is 12.5 gm% minimum.\n").append("Your last blood donation was 3 months earlier.\n").append("You are healthy and have not suffered from malaria, typhoid or other transmissible disease in the recent past.\n").append("\n").toString());
                headerMessage2.setVisibility(View.VISIBLE);
                headerMessage2.setText("Who can't donate blood:\n");
                showMessage2.setVisibility(View.VISIBLE);
                showMessage2.setText(new StringBuilder().append("Do not donate blood if you have any of these conditions...\n").append("Cold / fever in the past 1 week.\n").append("Under treatment with antibiotics or any other medication.\n").append("Cardiac problems, hypertension, epilepsy, diabetes (on insulin therapy), history of cancer,chronic kidney or liver disease, bleeding tendencies, venereal disease etc.\n").append("Vaccination in the last 24 hours.\n").append("Shared a needle to inject drugs/ have history of drug addiction.\n").append("Had sexual relations with different partners or with a high risk individual.\n").append("been tested positive for antibodies to HIV.\n").append("Pregnancy And Menstrual CycleB, Females should not donate blood during pregnancy.").toString());


            }
        });
        dayofDonation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessageCard.setVisibility(View.VISIBLE);
                showMessage2.setVisibility(View.GONE);
                headerMessage2.setVisibility(View.GONE);
                headerMessage.setText("Day of Donation ");
                showMessage.setText(new StringBuilder().append("\n").append("Drink an extra 16 oz. of water (or other nonalcoholic drink) before your appointment.\n").append("Eat a healthy meal, avoiding fatty foods like hamburgers, fries or ice cream.\n").append("Wear a shirt with sleeves that you can roll up above your elbows.\n").append("Let us know if you have a preferred arm or particular vein that has been used successfully in the past to draw blood.\n").append("Relax, listen to music, talk to other donors or read while you donate.\n").toString());
            }
        });


        return root;
    }
}