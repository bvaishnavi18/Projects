/*
 Navicat Premium Data Transfer

 Source Server         : highwayassiastance
 Source Server Type    : MySQL
 Source Server Version : 80031 (8.0.31)
 Source Host           : localhost:3306
 Source Schema         : highway

 Target Server Type    : MySQL
 Target Server Version : 80031 (8.0.31)
 File Encoding         : 65001

 Date: 15/03/2023 16:49:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `suggesition` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `rating` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES (1, '', '', 'Give rating');
INSERT INTO `feedback` VALUES (2, 'prakash jivtode', 'dd', '');
INSERT INTO `feedback` VALUES (3, 'prakash jivtode', 'good experience', '');
INSERT INTO `feedback` VALUES (4, 'prakash jivtode', 'good experience', '');
INSERT INTO `feedback` VALUES (5, 'prakash jivtode', '123', 'Give rating');
INSERT INTO `feedback` VALUES (6, 'prakash jivtode', 'it such a helpful application', '');
INSERT INTO `feedback` VALUES (7, '', '', 'Car service');
INSERT INTO `feedback` VALUES (8, '', '', 'Car service');
INSERT INTO `feedback` VALUES (9, 'pavan', '11', 'Excellent');
INSERT INTO `feedback` VALUES (10, 'pavan', '11', 'Excellent');
INSERT INTO `feedback` VALUES (11, 'Darshan', '234', 'Very Good');

-- ----------------------------
-- Table structure for provider
-- ----------------------------
DROP TABLE IF EXISTS `provider`;
CREATE TABLE `provider`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pemail` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `padhar` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `ppassword` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pmobile` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pdob` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `paddress` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pcity` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of provider
-- ----------------------------
INSERT INTO `provider` VALUES (1, 'shiva', 'shivajivtode1@email.com', '134562625', '111', '9877564546', '2023-03-29', 'nagpur', 'nagpur');
INSERT INTO `provider` VALUES (2, 'shiva', 'shivajivtode1@email.com', '1234', '11', '2345', '2023-03-17', 'shivaji nagar', 'pune');
INSERT INTO `provider` VALUES (3, 'shiva', 'shivajivtode1@email.com', '12345', '11', '8976456748', '2023-03-17', 'shivaji nagar', 'nagpur');
INSERT INTO `provider` VALUES (4, 'prakash jivtode', 'prakash@123', '87546746345', '1010', '9588418303', '2023-03-18', 'near dy patil college,akurdi 455676', 'pune');

-- ----------------------------
-- Table structure for service
-- ----------------------------
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `licence_no` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `adhar_no` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `city` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `location` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `service_type` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `sub_service_type` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `instruction` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `date_time` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `vehicle_name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `vehicle_no` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of service
-- ----------------------------
INSERT INTO `service` VALUES (2, 'Aditya', '', '405617980280', 'yeola', 'anand nagar vinchur road yeola', 'Car service', NULL, '  enter description', '2023-02-16T16:31', 'hyundai verna', 'mh 01 bd 2444');
INSERT INTO `service` VALUES (5, '', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (6, '', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (7, 'shiva', '456', '34', 'pune', 'pune', 'Car service', NULL, 'hii', '2023-02-28T11:45', 'tata', '5657');
INSERT INTO `service` VALUES (8, 'shiva', '12345', '12345', 'pune', 'pune', 'Car service', 'Puncture', 'hello', '2023-02-28T20:31', 'honda', '2345');
INSERT INTO `service` VALUES (9, 'shiva', '12345', '12345', 'pune', 'pune', 'Car service', 'Puncture', 'hello', '2023-02-28T20:31', 'honda', '2345');
INSERT INTO `service` VALUES (10, '', '', '', '', '', 'Bike Service', 'Battery', '', '', '', '');
INSERT INTO `service` VALUES (11, '', '', '', '', '', 'choose service type', 'Towing', '', '', '', '');
INSERT INTO `service` VALUES (12, '', '', '', '', '', 'choose service type', 'Towing', '', '', '', '');
INSERT INTO `service` VALUES (13, '', '', '', '', '', 'choose service type', 'Battery', '', '', '', '');
INSERT INTO `service` VALUES (14, 'shiva', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (15, 'shiva', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (16, 'shiva', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (17, 'shiva', '', '', '', '', 'choose service type', NULL, '  enter description', '', '', '');
INSERT INTO `service` VALUES (18, 'prakash jivtode', '1234567', '123456', 'nagpur', 'anand nagar vinchur road yeola', 'Bike Service', 'Battery', 'aaa', '2023-03-15T15:56', 'pulsar', 'mh12 bc 2020');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `mobileno` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (22, 'shiva jivtode', '1234', 'shivajivtode1@gmail.com', '9588418303');
INSERT INTO `users` VALUES (23, 'prakash jivtode', '123', 'Prakash@123', '8421115612');
INSERT INTO `users` VALUES (24, 'rutik mail', '54321', 'rutik@123', '1234567898');
INSERT INTO `users` VALUES (25, 'shiva', '123', 'prakash@123', '1234567890');
INSERT INTO `users` VALUES (26, 'darshan deulkar', '0000', 'darshan@123', '1238734527');
INSERT INTO `users` VALUES (27, 'suhas', '0000', 'suhas@123', '2435465768');
INSERT INTO `users` VALUES (28, 'sarang ', '54321', 'sarang@123', '897564736');
INSERT INTO `users` VALUES (29, 'pavan', '982205', 'shivajivtode1@gmail.com', '7378325498');
INSERT INTO `users` VALUES (30, 'prakash jivtode', '54321', 'prakash@1234', '9588418303');
INSERT INTO `users` VALUES (31, 'abc', '123', 'abc@1234', '786574837');
INSERT INTO `users` VALUES (32, 'mdA', '', 'm@123', '768675');
INSERT INTO `users` VALUES (33, 'akash', '9090', 'akash@123', '2345');
INSERT INTO `users` VALUES (34, 'shiva', '1', 'akash@123', '67587');
INSERT INTO `users` VALUES (35, 'shiva', '12', 'm@123', '');
INSERT INTO `users` VALUES (36, 'shiva', '12', 'm@123', '345');
INSERT INTO `users` VALUES (37, 'shiva', '12', 'm@123', '345');
INSERT INTO `users` VALUES (38, 'aa', '12', 'm@123', '68785');
INSERT INTO `users` VALUES (39, '54', '12', 'm@123', '75857564644848484');
INSERT INTO `users` VALUES (40, '54', '12', 'm@123', '75857564644848484');
INSERT INTO `users` VALUES (41, 'shiva', '12', 'm@123', '44');
INSERT INTO `users` VALUES (42, 'shiva', '12', 'm@123', '44');

SET FOREIGN_KEY_CHECKS = 1;
